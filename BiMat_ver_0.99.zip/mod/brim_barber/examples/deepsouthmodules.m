#! /usr/local/bin/octave
% DEEPSOUTHMODULES  analysis of Deep South dataset using BRIM algorithm
%
% This script serves two purposes. First, to test the various functions 
% used in implementing the BRIM algorithm by applying it to a well-studied
% dataset. Second, to provide an annotated example of how BRIM works, which
% should be helpful in further applications.
%

% $Author: mjb $
% $Date: 2007/06/14 14:59:49 $
% $Revision: 1.1 $
% $Log: deepsouthmodules.m,v $
% Revision 1.1  2007/06/14 14:59:49  mjb
% Initial revision
%
%


% Set up the bipartite modularity matrix for the Deep South data
ds = deepsouth();
numedges = sum(ds(:));
[numwomen, numevents] = size(ds);
modmat = bpmodmat(ds);

% Examine the singular values of the bipartite modularity matrix
[U, S, V] = svd(modmat);
singvals = diag(S);
figure(1);
plot(singvals, 'o')
xlabel('Order')
ylabel('Singular Value')

% From the singular value spectrum, we can see that one singular value is
% of larger value, with a roughly linearly decreasing distribution of the
% remaining values. It might be reasonable to limit the modularity
% matrix to rank one, but there does not seem to be a compelling reason
% to do so. Regardless, we constrain the rank to demonstrate limitrank.m. 
% The resulting division is an inefficient implementation of the leading
% eigenvector approach, dividing the vertices into two modules.

u1 = U(:,1)';
v1 = V(:,1)';
disp('Leading vector method');
disp('Module 1');
disp('Women:');
disp(find(u1 >= 0));
disp('Events:');
disp(find(v1 >= 0));
disp('Module 2');
disp('Women:');
disp(find(u1 < 0));
disp('Events:');
disp(find(v1 < 0));

ranklimited = limitrank(modmat, 1);
Trl0 = assignsamemodule(numevents, 2);
[Rrl, Trl, Qhist] = brim(ranklimited, Trl0, numedges, modmat);
disp('\nBRIM method');
disp('Module 1');
disp('Women:');
disp(find(Rrl(:,1))');
disp('Events:');
disp(find(Trl(:,1))');
disp('Module 2');
disp('Women:');
disp(find(Rrl(:,2))');
disp('Events:');
disp(find(Trl(:,2))');

figure(2);
plot(Qhist, 'o-')
xlabel('Step')
ylabel('Modularity')



% Since the BRIM algorithm uses a local search, the initial state can be
% important. This can show up in the quality of the stable solution (i.e.,
% getting stuck at a local maximum) or in the number of steps needed to
% stabilize. Investigate by trying various initial states with the full
% bipartite modularity matrix.

Tsame0 = assignsamemodule(numevents, numevents);
[Rsame, Tsame, Qsame] = brim(modmat, Tsame0, numedges);

Tuniq0 = assignuniqmodule(numevents);
[Runiq, Tuniq, Quniq] = brim(modmat, Tuniq0, numedges);

Tranda0 = assignrandmodule(numevents, numevents);
[Rranda, Tranda, Qranda] = brim(modmat, Tranda0, numedges);

Trandb0 = assignrandmodule(numevents, numevents);
[Rrandb, Trandb, Qrandb] = brim(modmat, Trandb0, numedges);

Trandc0 = assignrandmodule(numevents, numevents);
[Rrandc, Trandc, Qrandc] = brim(modmat, Trandc0, numedges);

figure(3);
plot(Qsame, 'ro-;Same;')
xlabel('Step')
ylabel('Modularity')
hold on
plot(Quniq, 'bx-;Unique;')
plot(Qranda, 'g+-;Random 1;')
plot(Qrandb, 'm+-;Random 2;')
plot(Qrandc, 'c+-;Random 3;')
hold off

% Now generate a larger number of random initial states, and see how
% well we can do. For comparison, we include the starting state with
% each vertex in its own module.
figure(4);
plot(Quniq, 'bx-;Unique;')
xlabel('Step')
ylabel('Modularity')
hold on
for cntr = 1:10
    Trand0 = assignrandmodule(numevents, numevents);
    [Rrand, Trand, Qrand] = brim(modmat, Trand0, numedges);
    plot(Qrand, 'ro-')
end
hold off

% To further check the possibilities of initial states, collect the 
% modularity for a larger number of random starting states.

numsamples = 100;
Qmaxlist = zeros(numsamples,1);
numModulesList = zeros(numsamples, 1);
for cntr=1:numsamples
    T0 = assignrandmodule(numevents, numevents);
    [R, T, Qhist] = brim(modmat, T0, numedges);
    Qmaxlist(cntr) = Qhist(length(Qhist));
    numModulesList(cntr) = length(find(any(R)));
end
figure(5);
plot(Qmaxlist, dither(numModulesList, 0.33), 'o')
xlabel("Modularity")
ylabel("Number of Modules")
% printf("Assignment to unique initial modules\n")
% printf("Modularity for stable solution: %g\n", Quniq(length(Quniq)))
% printf("\n\n")
% printf("Random initial assignment, with %d samples\n", numsamples)
% printf("Minimum modularity for stable solution: %g\n", min(Qmaxlist))
% printf("Maximum modularity for stable solution: %g\n", max(Qmaxlist))

% Now add some randomness to the search, as well as to the intial states.
mutationRates = linspace(0.7, 0, 20) .^ 2;
figure(6);
plot(Quniq, 'bx-;Unique;')
xlabel('Step')
ylabel('Modularity')
hold on
for cntr = 1:10
    Trand0 = assignuniqmodule(numevents);
    [mRrand, mTrand, mQrand] = mbrim(modmat, Trand0, mutationRates, numedges);
    [Rrand, Trand, Qrand] = brim(modmat, mTrand, numedges);
    plot([mQrand; Qrand], 'ro-')
end
hold off

% Collect results for a large number of runs of the mbrim version.

mnumsamples = 100;
mQmaxlist = zeros(mnumsamples,1);
mNumModulesList = zeros(mnumsamples, 1);
for cntr=1:mnumsamples
    T0 = assignrandmodule(numevents, numevents);
    [mR, mT] = mbrim(modmat, T0, mutationRates);
    [R, T, Qhist] = brim(modmat, mT, numedges);
    mQmaxlist(cntr) = Qhist(length(Qhist));
    mNumModulesList(cntr) = length(find(any(R)));
end
figure(7);
plot(Qmaxlist, dither(numModulesList, 0.33), 'ro;BRIM;',
     mQmaxlist, dither(mNumModulesList, 0.33), 'bx;mBRIM;')
xlabel("Modularity")
ylabel("Number of Modules")


