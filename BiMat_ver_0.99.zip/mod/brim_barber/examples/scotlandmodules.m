% SCOTLANDMODULES  analysis of Scotland interlock dataset using BRIM algorithm
%

% $Author: mjb $
% $Date: 2007/06/15 10:56:40 $
% $Revision: 1.4 $
% $Log: scotlandmodules.m,v $
% Revision 1.4  2007/06/15 10:56:40  mjb
% Renamed the traces showing the aBRIM results.
%
% Revision 1.3  2007/06/14 15:31:37  mjb
% Eliminated uninformative third figure. Added aBRIM traces to the figure
% showing the dependence of the modularity found on the number of allowed
% modules.
%
% Revision 1.2  2007/06/14 14:54:43  mjb
% Removed all of the mBRIM stuff.
%
%

% Set up the bipartite modularity matrix for the data
[bod, sctr, cap] = scotland();
bodEdges = sum(bod(:));
[numFirms, numDirs] = size(bod);
bodModmat = bpmodmat(bod);

% Examine the singular values of the BOD bipartite modularity matrix
[U, S, V] = svd(bodModmat);
singvals = diag(S);
figure(1);
plot(singvals, 'o')
xlabel('Order')
ylabel('Singular Value')

% The singular values are dominated by just a couple of larger ones, 
% with the remainder dropping off exponentially. We may expect that 
% just a few clusters should do the job, but we'll take a look at 
% larger numbers, to be sure. There doesn't seem to be much reason to view
% any of the singular values as corresponding to noise, so we'll skip
% limiting the rank on this basis 

Runiq0 = assignuniqmodule(numFirms);
[Tuniq, Runiq, Quniq] = brim(bodModmat', Runiq0, bodEdges);
Rsame0 = assignsamemodule(numFirms, numFirms);
[Tsame, Rsame, Qsame] = brim(bodModmat', Rsame0, bodEdges);

Rranda0 = assignrandmodule(numFirms, numFirms);
[Rranda, Tranda, Qranda] = brim(bodModmat', Rranda0, bodEdges);

Rrandb0 = assignrandmodule(numFirms, numFirms);
[Rrandb, Trandb, Qrandb] = brim(bodModmat', Rrandb0, bodEdges);

Rrandc0 = assignrandmodule(numFirms, numFirms);
[Rrandc, Trandc, Qrandc] = brim(bodModmat', Rrandc0, bodEdges);

figure(2);
plot(1:length(Qsame), Qsame, 'rx', ...
     1:length(Quniq), Quniq, 'bo', ...
     1:length(Qranda), Qranda, 'g+', ...
     1:length(Qrandb), Qrandb, 'm+', ...
     1:length(Qrandc), Qrandc, 'c+');
xlabel('Step');
ylabel('Modularity');
legend('Same','Unique','Random 1','Random 2','Random 3');
% Since the BRIM algorithm uses a local search, the initial state can be
% important. This can show up in the quality of the stable solution (i.e.,
% getting stuck at a local maximum) or in the number of steps needed to
% stabilize. Investigate by trying random initial states, and see how
% well we can do. 
%
% To investigate the possibilities of initial states, collect the 
% modularity for a large number of random starting states. Check the
% number of modules found as well. We'll use 7 different bounds on the
% number of modules, and the same number of samples for each bound.
%
% Also use an adaptive variant of BRIM that searches for an 
% appropriate value for the allowed number of modules. We'll take
% three samples with aBRIM.
%
numModuleBounds = [numFirms; 65; 40; 25; 15; 10; 5];
numSamples = 30;
QmaxFound = zeros(numSamples, length(numModuleBounds));
numModules = zeros(numSamples, length(numModuleBounds));

for bndCntr = 1:length(numModuleBounds)
    numMods = numModuleBounds(bndCntr);
    for sampCntr = 1:numSamples
        T0 = assignrandmodule(numDirs, numMods);
        [R, T, Qhist] = brim(bodModmat, T0, bodEdges);
        QmaxFound(sampCntr, bndCntr) = Qhist(length(Qhist));
        numModules(sampCntr, bndCntr) = length(find(any(R)));
    end
end

[R, T, Qhist1, Ahist1, Nhist1] = abrim(bodModmat, bodEdges);
[R, T, Qhist2, Ahist2, Nhist2] = abrim(bodModmat, bodEdges);
[R, T, Qhist3, Ahist3, Nhist3] = abrim(bodModmat, bodEdges);

figure(3);
dithNumModules = dither(numModules, 0.33);
plot(QmaxFound(:, 1), dithNumModules(:, 1), 'ro;Unrestricted;', 
     QmaxFound(:, 2), dithNumModules(:, 2), 'bx;Up to 65;', 
     QmaxFound(:, 3), dithNumModules(:, 3), 'g+;Up to 40;',
     QmaxFound(:, 4), dithNumModules(:, 4), 'm*;Up to 25;',
     QmaxFound(:, 5), dithNumModules(:, 5), 'co;Up to 15;',
     QmaxFound(:, 6), dithNumModules(:, 6), 'wx;Up to 10;',
     QmaxFound(:, 7), dithNumModules(:, 7), 'r+;Up to 5;',
	 Qhist1, Nhist1, 'r-;Adaptive 1;',
	 Qhist1(end), Nhist1(end), 'r*',
	 Qhist2, Nhist2, 'b-;Adaptive 2;',
	 Qhist2(end), Nhist2(end), 'b*',
	 Qhist3, Nhist3, 'g-;Adaptive 3;',
	 Qhist3(end), Nhist3(end), 'g*')
xlabel("Modularity")
ylabel("Number of Modules")
axis([.5, .7])

% Now compare the behavior of Ahist and Nhist
figure(4);
maxModules = max([max(Ahist1), max(Ahist2), max(Ahist3)]);
plot(Ahist1, Nhist1, 'r*',
	 Ahist2, Nhist2, 'b+',
	 Ahist3, Nhist3, 'go',
	 [0, maxModules], [0, maxModules], 'c-')
xlabel("Allowed modules");
ylabel("Identified modules");
