The BRIM algorithm is an algorithm for identifying clusters in
bipartite networks. This collection of Octave functions provides a
reference implementation of the BRIM algorithm. The functions are
written to be clear and readable, rather than optimized for speed
or memory usage; they are suitable for analyzing smaller networks.

The functions are divided amongst several directories along logical
lines. To install, either add the directories to your Octave path
or move the function files onto your existing Octave path.

The 'examples' directory contains two scripts to illustrate the use
of the various functions. The scripts are fairly similar, but examine
two different social networks of different sizes. First,
deepsouthmodules.m treats the standard Southern women dataset,
describing social interactions between 18 women based on participation
in 14 events. Second, scotlandmodules.m treats data on corporate
interlocks in Scotland during the early Twentieth Century. A good
starting point would be to look through the deepsouthmodules.m
script.

The example scripts are supported by the functions in the 'miscellaneous'
directory. These two functions are non-essential to the BRIM algorithm
reference implementation, and thus separate, but may be of use.

The 'networks' directory contains the implementation of the BRIM
algorithm, spread across several subdirectories. First, in the
'bipartite-modularity' subdirectory, the core BRIM algorithm and
several adaptive extensions are defined, as are functions for
calculating a modularity measure specialized for bipartite networks.
Second, in the 'bipartite-networks' subdirectory, several example
networks are given; 'deepsouth.m' and 'scotland.m' are used in the
example scripts. Third, in the 'block-models' subdirectory, functions
for working with bipartite analogs of the standard block-style model
networks are provided; these are most useful for testing purposes.
Fourth, the 'index-matrix' subdirectory presents a collection of
functions for working with matrices describing membership of vertices
in modules. Fifth, in the 'information-theory' subdirectory, two
functions are given for comparing assignments of vertex to modules
with information theoretic measures. Finally, in the 'membership'
subdirectory, three functions are given for working with the
membership of actors in groups in terms of graphs, converting group
membership to and from sets of edges and embedding the matrix
describing memberships into an adjacency matrix suitable for a
bipartite network.
