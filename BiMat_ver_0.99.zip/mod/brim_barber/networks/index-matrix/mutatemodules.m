function [indmat] = mutatemodules(indmat0, prob)

% MUTATEMODULES   Randomly reassign vertices to modules
%
%   "Mutates" vertices to new modules. Each vertex is reassigned with
%   probability PROB. Any vertex that is reasssigned is assigned to a 
%   random module, with all modules (including the original) being 
%   equally likely. The number of modules is taken from the number of
%   columns of INDMAT.
%   
%   SYNTAX
%       MUTATEMODULES(INDMAT, PROB)
%   

%
%   Created by Michael Barber on 2007-05-04.
%   Copyright (c)  Michael Barber. All rights reserved.
%

indmat = indmat0;
rows2change = rand(rows(indmat), 1) < prob;
if any(rows2change)
    rowIndices = find(rows2change);
    numModules = columns(indmat);
    modules = eye(numModules);
    modIndices = floor(rand(length(rowIndices), 1) * numModules) + 1;
    indmat(rows2change, :) = modules(modIndices, :);
end