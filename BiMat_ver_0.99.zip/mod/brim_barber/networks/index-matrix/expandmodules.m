function [newindex] = expandmodules(indmat, newmodsize, reassignprob)

% EXPANDMODULES   Expand index matrix to allow more modules
%
%   Expands an index matrix INDMAT to allow NEWMODSIZE modules  
%   to be addressed. Vertices are reassigned from their previous 
%   modules to occupy the newly created modules with probability 
%   REASSIGNPROB. The number of vertices is not changed.
%
%   NEWMODSIZE must be greater than the number of modules 
%   addressed by INDMAT, i.e., the number of columns of INDMAT. 
%   
%   SYNTAX
%       EXPANDMODULES(INDMAT, NEWMODSIZE, REASSIGNPROB)
%   

%
%   Created by Michael Barber on 2007-06-05.
%   Copyright (c)  Michael Barber. All rights reserved.
%

[numVertices, origMods] = size(indmat);
newmods = newmodsize - origMods;
if newmods <= 0
    error('Number of modules must increase. Original: %d. New: %d', origMods, newmodsize)
end

reassignVertices = find(rand(numVertices, 1) < reassignprob);
numReassign = length(reassignVertices);

% Make random assignment of selected vertices to the new modules,
% then embed the random assignment into a list of all the vertices.
% Vertices that don't get reassigned are left as zero in the new
% matrix, those that do get reassigned are overwritten with zeros
% in the old matrix.

embedReassigned = zeros(numVertices, newmods);
embedReassigned(reassignVertices, :) = assignrandmodule(numReassign, newmods);

overwriteReassigned = indmat;
overwriteReassigned(reassignVertices, :) = zeros(numReassign, origMods);

newindex = [overwriteReassigned, embedReassigned];