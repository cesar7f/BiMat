function [indmat] = assignrandmodule(numverts, nummods)

% ASSIGNRANDMODULE   Assign network vertices to random modules
%
%   Assigns each network vertex to a random module. Returns an index 
%   matrix with the given number of vertices and modules. All vertices 
%   are assigned to modules with equiprobability. Modules may be empty.
%   
%   SYNTAX
%       [INDMAT] = ASSIGNRANDMODULE(NUMVERTS, NUMMODS)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

modules = eye(nummods);
indices = floor(rand(numverts, 1) * nummods) + 1;
indmat = reorderemptymodules(modules(indices, :));
