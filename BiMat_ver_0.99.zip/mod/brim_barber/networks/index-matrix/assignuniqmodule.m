function [indmat] = assignuniqmodule(numverts)

% ASSIGNUNIQMODULE   Assign network vertices to unique module
%
%   Assigns all network vertices to a different modules. Returns an 
%   index matrix with the given number of vertices. Each vertex i is 
%   assigned to module i.
%   
%   SYNTAX
%       [INDMAT] = ASSIGNUNIQMODULE(NUMVERTS)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

indmat = eye(numverts);
