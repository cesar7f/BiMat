function modeq = samemodules(indmat1, indmat2)

% SAMEMODULES   Test module assignments for equality
%
%   Tests two index matrices showing module assignments for equality. 
%   Returns true (1) if all the modules are identical, and false (0) 
%   otherwise.
%
%   Raises an error if the index matrices are not of the same size.
%   
%   SYNTAX
%       MODEQ = SAMEMODULES(INDMAT1, INDMAT2)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

modeq = all(all(indmat1 == indmat2));