function [numModules] = countmodules(indmat)

% COUNTMODULES   Count number of modules occupied.
%
%	Counts the number of modules occupied in INDMAT. The number of 
%	modules is given by the number of non-zero columns of INDMAT. For 
%	a valid index matrix, there is always at least one and at most 
%	COLUMNS(INDMAT) modules.
%	
%	SYNTAX
%		[NUMMODULES] = COUNTMODULES(INDMAT)
%	

%
%	Created by Michael Barber on 2007-06-18.
%	Copyright (c)  Michael Barber. All rights reserved.
%

numModules = sum(any(indmat));
