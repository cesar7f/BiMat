function [indmat] = assignsamemodule(numverts, nummods)

% ASSIGNSAMEMODULE   Assign all network vertices to one module
%
%   Assigns all network vertices to a single module. Returns an index 
%   matrix with the given number of vertices and modules. All vertices 
%   are assigned to the first module.
%   
%   SYNTAX
%       [INDMAT] = ASSIGNSAMEMODULE(NUMVERTS, NUMMODS)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

indmat = [ones(numverts, 1), zeros(numverts, nummods - 1)];
