function [indmat2] = reorderemptymodules(indmat1)

% REORDEREMPTYMODULES   Assign empty modules to highest indices
%
%   Reorders network modules so that any empty modules correspond to 
%   the highest indices. In terms of the index matrix, any all-zero 
%   columns of the matrix are shifted to the right side of the matrix. 
%   
%   SYNTAX
%       [INDMAT2] = REORDEREMPTYMODULES(INDMAT1)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

nonzerocols = find(any(indmat1));
if length(nonzerocols) == max(nonzerocols)
    indmat2 = indmat1;
else
    numverts = size(indmat1,1);%rows(indmat1);
    numemptymods = size(indmat1,2) - length(nonzerocols);%columns(indmat1) - length(nonzerocols);
    indmat2 = [indmat1(:, nonzerocols), zeros(numverts, numemptymods)];
end
