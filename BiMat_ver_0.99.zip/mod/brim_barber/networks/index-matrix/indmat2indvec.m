function indvec = indmat2indvec(indmat)
%
% indmat2indvec(indmat) Convert index matrix to vector of indices
%

[X, Y] = find(indmat);
indvec = zeros(size(X));
indvec(X) = Y;