function modmat = bpmodmat(membership,p_type)

% BPMODMAT   Calculate modularity matrix for bipartite network
%
%   Calculates the relevant submatrix of the modularity matrix for
%   an unweighted bipartite network. The matrix is calculated from
%   the membership matrix giving the edges between the two parts 
%   of the network, which is an m by n submatrix of the adjacency 
%   matrix. The returned network is also m by n, with the elements 
%   defined as the difference between the actual membership and the
%   expected membership in a null model where edges are randomly 
%   assigned with probabilities proportional to the degrees of the
%   vertices at the ends of the edges.
%   
%   SYNTAX
%       MODMAT = BPMODMAT(MEMBERSHIP)
%   

%
%   Created by Michael Barber on 2007-03-26.
%   Copyright (c)  Michael Barber. All rights reserved.
%

if all(all(membership == 0))
    modmat = membership;
else
    coldeg = sum(membership, 1);
    rowdeg = sum(membership, 2);
    numedges = sum(rowdeg);
    pp = (1/numedges) * rowdeg * coldeg;
    %pp = min((1/numedges) * rowdeg * coldeg,1);
    C = numedges;
    [H P] = size(membership);
    pp_josh = zeros(size(membership));
    pp_gabriel = pp_josh;
    pp_gabriel_first = pp_josh;
    for i = 1:H
        for j = 1:P
            numer = (C-rowdeg(i)-coldeg(j)+1) * (P-rowdeg(i)) * (H-coldeg(j));
            demer = (H*P - H - P + 1 - C + rowdeg(i) + coldeg(j)) * (rowdeg(i)*coldeg(j));
            pp_josh(i,j) = 1/(1 + numer/demer);
            kprime = (C-rowdeg(i)-coldeg(j));
            numer = rowdeg(i)*coldeg(j)*kprime;
            demer = (P-rowdeg(i))*(H-coldeg(j))*((H-1)*(P-1)-kprime+1) + rowdeg(i)*coldeg(j)*kprime;
            pp_gabriel(i,j) = numer/demer;
            numer = rowdeg(i)*coldeg(j);
            demer = (P-rowdeg(i))*(H-coldeg(j))+numer;
            pp_gabriel_first(i,j) = numer/demer;
        end
    end
    
    
    if(nargin==2)
        if(p_type == 1)
            modmat = membership - pp_josh;
        elseif(p_type == 2)
            modmat = membership - pp_gabriel;
        elseif(p_type == 3)
            pp_simulated = create_numerical_p(membership);
            modmat = membership - pp_simulated;
        else
            modmat = membership - pp;
        end
    else
        modmat = membership - pp;
    end
        
    
end