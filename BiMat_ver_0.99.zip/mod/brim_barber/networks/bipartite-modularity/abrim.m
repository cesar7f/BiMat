function [R, T, Qhist, Ahist, Nhist] = abrim(bpmodmat, numedges, modularitybpmodmat)

% ABRIM   Identify modules in a bipartite network
%
%   Identifies bipartite network modules using the BRIM (bipartite, 
%   recursively induced modules) algorithm with an adaptive search
%   for the optimal number of modules to allow.
%
%   Takes as input the (possibly rank-limited) modularity matrix
%   bpmodmat and the number of edges in the network. The putative 
%   number of modules is automatically assigned using a bisecting 
%   search. Modules are identified for an allowed number of modules 
%   by a local search algorithm that optimizes the modularity. The 
%   modularity values found are in turn used to search for a value 
%   of the allowed number of modules that gives better modularity 
%   results, hopefully avoid local maxima in the modularity landscape.
%   Note that, unlike BRIM, the number of edges is not optional.
%
%   This algorithm always terminates at a maximum of the modularity.  
%   Normally, this is a local maximum, not the global maximum.
%
%   Returns index matrices R and T for the two parts of the network. 
%   The sizes of the matricies are such that R' * bpmodmat * T is well
%   defined and the two index matrices R and T both have the same
%   number of columns. In terms of the network, the number of modules
%   equals the number of columns of R and T and the number of vertices 
%   for the two parts of the network are the number of rows in R and T.
%   
%   The third output argument is a vector QHIST showing the history of
%   the maximal modularity values. Note that, unlike with BRIM, the
%   modularity history is based on iterations of the search for the
%   optimal number of allowed modules. The length of QHIST is one more
%   than the number of iterations of the module-number search needed to 
%   find a solution. 
%
%   The fourth output argument is a vector AHIST showing the history of 
%   the number of modules allowed. Element N of the vector shows the 
%   number of allowed modules which led to the greatest modularity value 
%   found in the Nth iteration of the search algorithm for the number of 
%   modules; each iteration involves a BRIM search. There may be repeated 
%   values corresponding to the same value of the modularity. The length 
%   of AHIST always equals the length of QHIST.
%
%   The fifth output argument is a vector NHIST showing the history of
%   the number of modules identified. The length of NHIST always equals 
%   the length of AHIST and QHIST. Each element of NHIST is always at 
%   most equal to the corresponding element of AHIST. 
%
%   As well, an optional third input argument can be provided, giving
%   a bipartite modularity matrix for calculation of the modularity 
%   values. This can be useful if, e.g, bpmodmat is a low-rank 
%   approximation to the full bipartite modularity matrix. 
%
%   SYNTAX
%       [R, T, QHIST, AHIST, NHIST] = ABRIM(BPMODMAT, NUMEDGES)
%       [R, T, QHIST, AHIST, NHIST] = ABRIM(BPMODMAT, NUMEDGES, MODULARITYBPMODMAT)
%

%
%   Created by Michael Barber on 2007-06-12.
%   Copyright (c)  Michael Barber. All rights reserved.
%


% We need to identify an appropriate value N for the number of allowed
% modules. The strategy used here is to start with a small value and 
% continually extrapolate rightward while the modularity value Q is
% increasing. Once it drops, we know we've crossed a maximum. We then
% switch to interpolating within the range where we know the maximum 
% must lie. 
%
% We implement the search strategy as a state machine. The machine 
% states indicate what sort of search we use. There are two types
% of search, extrapolating and interpolating. Extrapolation is always
% to the right, while interpolation can occur in either the left or 
% right subinterval. The machine states are:
%   (1) Solution found, search complete.
%   (2) Extrapolating to the right.
%   (3) Selecting subinterval for interpolation.
%   (4) Interpolating in the left subinterval.
%   (5) Interpolating in the right subinterval.
% Once interpolation begins, there is no return to the extrapolating 
% state, by design. Termination is guaranteed.
%
% The states track three modularity values--Qa, Qb, and Qc--and three
% values for the allowed number of modules--Na, Nb, and Nc. Corresponding
% index matrices are also tracked, both to record the best solution found 
% and to generate new trial solutions. The modularity and allowed number
% of modules for the best found solutions are also tracked.
%


% Handle inputs
if nargin < 3
    modularitybpmodmat = bpmodmat;
end

[numRverts, numTverts] = size(bpmodmat);
maxNumModules = min(numRverts, numTverts);

% handle trivial cases
if maxNumModules == 0
    R = [];
    T = [];
    Qhist = [];
    Ahist = [];
    Nhist = [];
    return
elseif maxNumModules == 1
    R = assignsamemodule(numRverts, 1);
    T = assignsamemodule(numTverts, 1);
    Qhist = [0];
    Ahist = [1];
    Nhist = [1];
    return
elseif maxNumModules == 2
    T0 = assignrandmodule(numTverts, 2);
    [R, T, Qbrim] = brim(bpmodmat, T0, numedges, modularitybpmodmat);
    Qmax = max(Qbrim);
    if Qmax < 0
        Qhist = [0];
        Ahist = [1];
        Nhist = [1];
    else
        Qhist = [0; Qmax];
        Ahist = [1; 2];
        Nhist = [1; countmodules(T)];
    end
    return
end

% Define the states
SOLUTION_FOUND = 1;
EXTRAPOLATE_RIGHT = 2;
SELECT_SUBINTERVAL = 3;
INTERPOLATE_LEFT = 4;
INTERPOLATE_RIGHT = 5;

% Initialize state machine. We always start by extrapolating to the
% right, so we can just assign two meaninful states for the 'b' and 
% 'c' solutions and an arbitrary state for the 'a' solution, which 
% is always dropped in rightward extrapolation. We can start with all
% vertices in one module and expand once. The all-in-one solution can
% serve as both the 'a' and 'b' solutions, and the expanded solution
% can serve as the 'c' solution.

Na = 1;
Ta = assignsamemodule(numTverts, Na);
Qa = 0;

Nb = Na;
Tb = Ta;
Qb = Qa;

Nc = 2 * Nb;
T0 = expandmodules(Tb, Nc, 0.5);
[Rbrim, Tc, Qbrim] = brim(bpmodmat, T0, numedges, modularitybpmodmat);
Qc = Qbrim(end);

Qhist = [Qb; Qc];
Ahist = [Nb; Nc];
Nhist = [countmodules(Tb); countmodules(Tc)];

Qbest = Qc;
Nbest = Nc;

state = EXTRAPOLATE_RIGHT;

% Define state transitions

while ~(state == SOLUTION_FOUND)
    if state == EXTRAPOLATE_RIGHT
        % Drop left point
        Na = Nb;
        Qa = Qb;
        Ta = Tb;
        Nb = Nc;
        Qb = Qc;
        Tb = Tc;
        
        % Expand rightward
        Nc = min(Nb * 2, maxNumModules);
        T0 = expandmodules(Tb, Nc, 0.5);
        [Rbrim, Tc, Qbrim] = brim(bpmodmat, T0, numedges, modularitybpmodmat);
        Qc = Qbrim(end);
        if Qc >= Qbest
            Qbest = Qc;
            Nbest = Nc;
        end
        
        % Record trial solution
        Qhist = [Qhist; Qc];
        Ahist = [Ahist; Nc];
        Nhist = [Nhist; countmodules(Tc)];
        
        % Determine new state
        if (Nc < maxNumModules) && (Qc == Qbest)
            state = EXTRAPOLATE_RIGHT;
        else
            state = SELECT_SUBINTERVAL;
        end
    
    elseif state == SELECT_SUBINTERVAL
        % No trial solutions here, just dispatch to subintervals
        if Na + 2 == Nc
            state = SOLUTION_FOUND;
        elseif Na + 1 == Nb
            state = INTERPOLATE_RIGHT;
        elseif Nb + 1 == Nc
            state = INTERPOLATE_LEFT;
        elseif Qa == Qbest
            state = INTERPOLATE_LEFT;
        elseif Qc == Qbest
            state = INTERPOLATE_RIGHT;
        elseif (Nc - Nb) > (Nb - Na)
            state = INTERPOLATE_RIGHT;
        else
            state = INTERPOLATE_LEFT;
        end
        
    elseif state == INTERPOLATE_RIGHT
        % Determine trial solution
        Ntry = floor((Nb + Nc) / 2);
        T0 = expandmodules(Tb, Ntry, 0.5);
        [Rbrim, Ttry, Qbrim] = brim(bpmodmat, T0, numedges, modularitybpmodmat);
        Qtry = Qbrim(end);
        
        % Record trial solution
        Qhist = [Qhist; Qtry];
        Ahist = [Ahist; Ntry];
        Nhist = [Nhist; countmodules(Ttry)];
        
        % Determine new state
        if Qtry >= Qbest
            Qbest = Qtry;
            Nbest = Ntry;
            Na = Nb;
            Qa = Qb;
            Ta = Tb;
            Nb = Ntry;
            Qb = Qtry;
            Tb = Ttry;
        elseif (Qa == Qbest) || (Qb == Qbest)
            Nc = Ntry;
            Qc = Qtry;
            Tc = Ttry;
        else
            assert(Qc == Qbest);
            Na = Nb;
            Qa = Qb;
            Ta = Tb;
            Nb = Ntry;
            Qb = Qtry;
            Tb = Ttry;
        end
        
        state = SELECT_SUBINTERVAL;
    else
        assert(state == INTERPOLATE_LEFT)
        
        % Determine trial solution
        Ntry = floor((Na + Nb) / 2);
        T0 = expandmodules(Ta, Ntry, 0.5);
        [Rbrim, Ttry, Qbrim] = brim(bpmodmat, T0, numedges, modularitybpmodmat);
        Qtry = Qbrim(end);
        
        % Record trial solution
        Qhist = [Qhist; Qtry];
        Ahist = [Ahist; Ntry];
        Nhist = [Nhist; countmodules(Ttry)];
        
        % Determine new state
        if Qtry >= Qbest
            Nbest = Ntry;
            Qbest = Qtry;
            Nc = Nb;
            Qc = Qb;
            Tc = Tb;
            Nb = Ntry;
            Qb = Qtry;
            Tb = Ttry;
        elseif (Qb == Qbest) || (Qc == Qbest)
            Na = Ntry;
            Qa = Qtry;
            Ta = Ttry;
        else
            assert(Qa == Qbest);
            Nc = Nb;
            Qc = Qb;
            Tc = Tb;
            Nb = Ntry;
            Qb = Qtry;
            Tb = Ttry;
        end
        
        state = SELECT_SUBINTERVAL;
    end
end

% Solution reached. Now just need to pick the solution with the 
% largest Q value, use inducemodules to find the R index matrix, and
% append the final state values to the N and Q histories.
if Qb == Qbest
    T = Tb;
elseif Qa == Qbest
    T = Ta;
else
    assert(Qc == Qbest);
    T = Tc;
end
R = inducemodules(bpmodmat, T);
Qhist = [Qhist; Qbest];
Ahist = [Ahist; Nbest];
Nhist = [Nhist; countmodules(T)];


