function [Q] = bpmodularity(indmat1, bpmodmat, indmat2, numedges)

% BPMODULARITY   Modularity of bipartite network
%
%   Calculates the modularity for a bipartite network. 
%   
%   SYNTAX
%       [Q] = BPMODULARITY(INDMAT1, BPMODMAT, INDMAT2, NUMEDGES)
%   

%
%   Created by Michael Barber on 2007-04-04.
%   Copyright (c)  Michael Barber. All rights reserved.
%

Q = trace(indmat1' * bpmodmat * indmat2) / numedges;
