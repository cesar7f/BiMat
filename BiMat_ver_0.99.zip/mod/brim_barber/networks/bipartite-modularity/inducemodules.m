function [indmat2] = inducemodules(bpmodmat, indmat1)

% INDUCEMODULES   Use one part of bipartite network to induce modules in the other part
%
%   For a bipartite network, calculate the optimal assignment of the
%   vertices of one part of the network to modules assuming that the 
%   vertices of other part are correctly assigned. Optimality is in 
%   the sense of maximizing modularity.
%   
%   SYNTAX
%       [INDMAT2] = INDUCEMODULES(BPMODMAT, INDMAT1)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

[maxval, maxind] = max(bpmodmat * indmat1, [], 2);
modules = eye(columns(indmat1));
indmat2 = modules(maxind, :);
