function [R, T, Qhist] = brim(bpmodmat, T0, numedges, modularitybpmodmat)

% BRIM   Identify modules in a bipartite network
%
%   Identifies bipartite network modules using the BRIM (bipartite, 
%   recursively induced modules) algorithm. Takes as input the
%   (possibly rank-limited) modularity matrix bpmodmat and an index
%   matrix T0 showing the initial assignment of the vertices of
%   one part to modules. The putative number of modules is taken
%   from the number of columns of T0 (although some modules may
%   not be assigned any vertices). Modules are identified by a local
%   search algorithm that optimizes the modularity, terminating when
%   the vertex assignments stabilize upon reaching a (local) optimum.
%
%   Returns index matrices R and T for the two parts of the network. 
%   The sizes of the matricies are such that R' * bpmodmat * T is well
%   defined, T has the same size as T0, and R and T have the same
%   number of columns. In terms of the network, the number of modules
%   equals the number of columns of R and T and the number of vertices 
%   for the two parts of the network are the number of rows in R and T.
%   
%   The function can be called with an optional third output argument. 
%   If so, a vector is returned showing the value of the modularity 
%   after each search step. In order to calculate the modularity, the
%   number of edges must be given as a third input argument.
%
%   As well, an optional fourth input argument can be provided, giving
%   an bipartite modularity matrix for calculation of the modularity 
%   values. This can be useful if, e.g, bpmodmat is a low-rank 
%   approximation to the full bipartite modularity matrix. 
%
%   SYNTAX
%       [R, T] = BRIM(BPMODMAT, T0)
%       [R, T, QHIST] = BRIM(BPMODMAT, T0, NUMEDGES)
%       [R, T, QHIST] = BRIM(BPMODMAT, T0, NUMEDGES, MODULARITYBPMODMAT)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

if nargout > 2
    shouldrecordmodularity = 1;
    Qhist = [];
    if nargin < 3
        error('NUMEDGES must be given to calculate the modularity history')
    elseif nargin < 4
        modularitybpmodmat = bpmodmat;
    elseif ~all(size(bpmodmat) == size(modularitybpmodmat))
        error('BPMODMAT and MODULARITYBPMODMAT must be the same size');
    end
else
    shouldrecordmodularity = 0;
end

[numRverts, numTverts] = size(bpmodmat);
numModules = columns(T0);

%size(T0)
%size(bpmodmat)

if numTverts ~= rows(T0)
    error('Number of columns of BPMODMAT must equal number of rows of T0');
end

% Set initial state; assign impossible R-indices for initial state
R = zeros(numRverts, numModules);
T = T0;

while true
    % Calculate R-indices from T-indices
    R0 = R;
    R = inducemodules(bpmodmat, T);
    if samemodules(R, R0)
        break
    end
    if shouldrecordmodularity
        Qhist = [Qhist; bpmodularity(R, modularitybpmodmat, T, numedges)];
    end
    
    % Calculate T-indices from R-indices
    T0 = T;
    T = inducemodules(bpmodmat', R);
    if samemodules(T, T0)
            break
    end
    if shouldrecordmodularity
        Qhist = [Qhist; bpmodularity(R, modularitybpmodmat, T, numedges)];
    end
    
end

% Clean up module presentation
T = reorderemptymodules(T);
R = inducemodules(bpmodmat, T);
