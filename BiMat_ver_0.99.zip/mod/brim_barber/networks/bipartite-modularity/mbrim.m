function [R, T, Qhist] = mbrim(bpmodmat, T0, mutrates, numedges, modularitybpmodmat)

% MBRIM   Identify modules in a bipartite network
%
%   Identifies bipartite network modules using the BRIM (bipartite, 
%   recursively induced modules) algorithm with mutation.
%
%   Takes as input the (possibly rank-limited) modularity matrix
%   bpmodmat, an index matrix T0 showing the initial assignment of the
%   vertices of one part to modules, and a vector MUTRATES of mutation
%   rates. The putative number of modules is taken from the number of
%   columns of T0 (although some modules may not be assigned any
%   vertices). Modules are identified by a local search algorithm that
%   optimizes the modularity, combined with a mutation step consisting
%   of random reassignment of vertices to modules. For each element of
%   MUTRATES, the vertices are first reassigned to modules with 
%   probability of reassignment given by the element, followed by 
%   optimization using a BRIM algorithm step. There is no guarantee
%   that this function terminates at a maximum of the modularity; a
%   maximum can be obtained by calling BRIM with the results of MBRIM.
%
%   Returns index matrices R and T for the two parts of the network. 
%   The sizes of the matricies are such that R' * bpmodmat * T is well
%   defined, T has the same size as T0, and R and T have the same
%   number of columns. In terms of the network, the number of modules
%   equals the number of columns of R and T and the number of vertices 
%   for the two parts of the network are the number of rows in R and T.
%   
%   The function can be called with an optional third output argument. 
%   If so, a vector is returned showing the value of the modularity 
%   after each search step. In order to calculate the modularity, the
%   number of edges must be given as a fourth input argument.
%
%   As well, an optional fifth input argument can be provided, giving
%   a bipartite modularity matrix for calculation of the modularity 
%   values. This can be useful if, e.g, bpmodmat is a low-rank 
%   approximation to the full bipartite modularity matrix. 
%
%   SYNTAX
%       [R, T] = BRIM(BPMODMAT, T0, MUTRATES)
%       [R, T, QHIST] = BRIM(BPMODMAT, T0, MUTRATES, NUMEDGES)
%       [R, T, QHIST] = BRIM(BPMODMAT, T0, MUTRATES, NUMEDGES, MODULARITYBPMODMAT)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

if nargout > 2
    shouldrecordmodularity = 1;
    Qhist = [];
    if nargin < 4
        error('NUMEDGES must be given to calculate the modularity history')
    elseif nargin < 5
        modularitybpmodmat = bpmodmat;
    elseif ~all(size(bpmodmat) == size(modularitybpmodmat))
        error('BPMODMAT and MODULARITYBPMODMAT must be the same size');
    end
else
    shouldrecordmodularity = 0;
end

[numRverts, numTverts] = size(bpmodmat);
numModules = columns(T0);

if numTverts ~= rows(T0)
    error('Number of columns of BPMODMAT must equal number of rows of T0');
end

% Set initial state; assign impossible R-indices for initial state
R = zeros(numRverts, numModules);
T = T0;

for mr = mutrates
    % Calculate R-indices from T-indices
    T = mutatemodules(T, mr);
    R = inducemodules(bpmodmat, T);
    if shouldrecordmodularity
        Qhist = [Qhist; bpmodularity(R, modularitybpmodmat, T, numedges)];
    end
    
    % Calculate T-indices from R-indices
    R = mutatemodules(R, mr);
    T = inducemodules(bpmodmat', R);
    if shouldrecordmodularity
        Qhist = [Qhist; bpmodularity(R, modularitybpmodmat, T, numedges)];
    end
    
end
