function membmat = bpblockmodules(probin, probcross, nummods, numred, numblue)

% bpblockmodules   membership matrix for block-style bipartite network
%

probmat = bpblockmodulesprob(probin, probcross, nummods, numred, numblue);
membmat = rand(size(probmat)) < probmat;
