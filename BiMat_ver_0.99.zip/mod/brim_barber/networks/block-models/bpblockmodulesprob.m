function probmat = bpblockmodulesprob(probin, probcross, nummods, numred, numblue)

% bpblockmodulesprob   probability matrix for block-style bipartite network
%

% Create a matrix of probabilities for module constituents
probmod = (probin-probcross)*eye(nummods) + probcross*ones(nummods, nummods);

% Expand module-level probability matrix to vertex-level probability matrix
probmat = kron(probmod, ones(numred, numblue));
