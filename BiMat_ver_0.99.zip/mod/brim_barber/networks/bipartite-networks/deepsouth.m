function [dsmat] = deepsouth()

% DEEPSOUTH   Deep South dataset
%
%   Membership matrix for the Deep South dataset, showing the participation
%   of 18 southern women in 14 social events. The women are in the rows and
%   the events are in the columns.
%
%   The ordering of the rows and columns is taken from Table 2 of 
%   P. Doreian et al., Social Networks 26 (2004).
%   
%   SYNTAX
%       [DSMAT] = DEEPSOUTH()
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

dsmat = [1 1 1 1 1 1 0 1 1 0 0 0 0 0
         1 1 1 0 1 1 1 1 0 0 0 0 0 0
         0 1 1 1 1 1 1 1 1 0 0 0 0 0
         1 0 1 1 1 1 1 1 0 0 0 0 0 0
         0 0 1 1 1 0 1 0 0 0 0 0 0 0
         0 0 1 0 1 1 0 1 0 0 0 0 0 0
         0 0 0 0 1 1 1 1 0 0 0 0 0 0
         0 0 0 0 0 1 0 1 1 0 0 0 0 0
         0 0 0 0 1 0 1 1 1 0 0 0 0 0
         0 0 0 0 0 0 1 1 1 0 0 1 0 0
         0 0 0 0 0 0 0 1 1 1 0 1 0 0
         0 0 0 0 0 0 0 1 1 1 0 1 1 1
         0 0 0 0 0 0 1 1 1 1 0 1 1 1
         0 0 0 0 0 1 1 0 1 1 1 1 1 1
         0 0 0 0 0 0 1 1 0 1 1 1 0 0
         0 0 0 0 0 0 0 1 1 0 0 0 0 0
         0 0 0 0 0 0 0 0 1 0 1 0 0 0
         0 0 0 0 0 0 0 0 1 0 1 0 0 0];
