function fullmat = bipartembed(submat)

% BIPARTEMBED   Embed submatrix into full matrix for bipartite network 
%
%   Embed submatrix M into a larger matrix B as off-diagonal blocks. 
%   The resulting matrix is of a form useful for working with bipartite
%   networks. For an m by n matrix M, B satisfies:
%       B = [zeros(m,m), M; M', zeros(n,n)]
%

%   Created by Michael Barber on 2007-08-22.
%   Copyright (c) Michael Barber. All rights reserved.
%

[m, n] = size(submat);
fullmat = [zeros(m, m), submat; submat', zeros(n, n)];
