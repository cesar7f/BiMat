function edges = memb2edges(membership)

% memb2edges    convert membership matrix to edge list 
%
%   Converts a membership matrix to a matrix giving a list of edges. The
%   membership matrix is a matrix containing zero and one elements. The
%   edge list is a matrix with two columns and a number of rows equal to 
%   the number of ones in the membership matrix. A one in element (r, c)
%   of the membership matrix indicates that the edge (r, c) is present
%   in the edge list. 
%
%   No particular order for the edges is guaranteed. However, the ordering
%   is consistent between calls of memb2edges.
%

[r, c] = find(membership);
edges = [r,c];