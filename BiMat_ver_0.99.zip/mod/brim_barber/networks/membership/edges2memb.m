function membership = edges2memb(edges)

% edges2memb    convert edge list to membership matrix
%
%   Converts a matrix giving a list of edges to a membership matrix. The
%   edge list should be a matrix with two columns and one row for each
%   edge. The edges are used to create a matrix of size equal to 
%   max(edgeList) with all elements zero or one. A one in element (r, c)
%   indicates that the edge (r, c) is present in the network, while a
%   zero indicates that the edge is absent.
%
% Syntax
%   edges2memb(edges)
%

membership = zeros(max(edges));
for e = edges'
    membership(e(1), e(2)) = 1;
end