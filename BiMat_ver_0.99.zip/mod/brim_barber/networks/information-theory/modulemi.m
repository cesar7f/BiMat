function mi = modulemi(indmat1, indmat2)
%
% modulemi(indmat1, indmat2)   Compare modules with mutual information 
%

N = indmat1' * indmat2;
mi = mutinf(N / sum(N(:)));
