function nmi = modulenmi(im1, im2)
%
% modulenmi(im1, im2)   Compare modules with normalized mutual information 
%

mi = modulemi(im1, im2);

p1 = sum(im1);
p2 = sum(im2);
h1 = entropy(p1 / sum(p1));
h2 = entropy(p2 / sum(p2));

nmi = 2 * mi / (h1 + h2);
