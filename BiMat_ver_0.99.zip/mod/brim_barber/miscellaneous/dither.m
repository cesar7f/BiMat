function [dithdata] = dither(datamat, stdev)

% DITHER   Randomly shift data
%
%   Randomly shifts data by adding zero-mean Gaussian noise  
%   with standard deviation STDEV to each element of DATAMAT.
%   
%   SYNTAX
%       DITHER(DATAMAT, STDEV)
%   

%
%   Created by Michael Barber on 2007-05-07.
%   Copyright (c)  Michael Barber. All rights reserved.
%

dithdata = datamat + stdev * randn(size(datamat));