function ncol = columns(matrix) 

ncol = size(matrix,2);