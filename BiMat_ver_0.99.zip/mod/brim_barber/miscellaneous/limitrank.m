function ranklimited = limitrank(matrix, maxrank)

% LIMITRANK   Constrain the rank of a matrix
%
%   Returns a matrix which is the closest approximation to the
%   input matrix having rank at most maxrank.
%   
%   SYNTAX
%       RANKLIMITED = LIMITRANK(MATRIX, MAXRANK)
%   

%
%   Created by Michael Barber on 2007-04-03.
%   Copyright (c)  Michael Barber. All rights reserved.
%

[U, S, V] = svd(matrix);
singvals = diag(S);
if length(singvals) < maxrank
    ranklimited = matrix;
else
    ranklimited = U(:, 1:maxrank) * S(1:maxrank, 1:maxrank) * V(:, 1:maxrank)';
end