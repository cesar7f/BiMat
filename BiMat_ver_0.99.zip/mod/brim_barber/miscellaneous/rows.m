function nrow = rows(matrix) 

nrow = size(matrix,1);