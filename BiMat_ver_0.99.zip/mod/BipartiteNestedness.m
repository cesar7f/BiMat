classdef BipartiteModularity < handle
   
    properties
       
        matrix               = [];  %Bipartite adjacency matrix
        rr                   = [];  %Red Nodes (rows) Communities matrix. Size = n_rows*CommunityQuantity
        tt                   = [];  %Blue Nodes (columns) Communities. Size = n_cols*CommunityQuantity
        rr_sorted            = [];
        tt_sorted            = [];
        n_rows               = 0;   %Number of rows
        n_cols               = 0;   %Number of columns
        n_edges              = 0;
        bb                   = [];  %Original - Null.
        index_rows           = [];  %Register of the swaps in Rows.
        index_cols           = [];  %Register of the swaps in Cols.
        trials               = 10;
        Qb                   = 0;
        Qr                   = 0;
        N                    = 0;
        row_modules          = [];
        col_modules          = [];
        done                 = 0;
        webmatrix            = [];
        %use_global_bb        = 1;
    end
    
    methods(Abstract)
        
        obj = DetectComponent(obj);
        
    end
    
    methods
       
        function obj = BipartiteModularity(bipmatrix)
            
            obj.webmatrix = bipmatrix;
            obj.matrix = bipmatrix > 0;
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            obj.trials = 100;
            obj.n_edges = sum(sum(obj.matrix));
            
        end
        
        function obj = Detect(obj,ntrials)
            
            if(nargin == 2)
                obj.trials = ntrials;
            end
            
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            
            mm = [zeros(obj.n_rows, obj.n_rows) obj.matrix; obj.matrix' zeros(obj.n_cols, obj.n_cols)];
            [S, C] = graphconncomp(sparse(mm),'Weak', true);
            
            C_rows = C(1:obj.n_rows);
            C_cols = C(1+obj.n_rows:obj.n_rows+obj.n_cols);
            matrix_global = obj.matrix;
            rows_empty = [];
            cols_empty = [];
            rr_global = [];
            tt_global = [];
            index_rows_global = 1:obj.n_rows;
            index_cols_global = 1:obj.n_cols;
            row_modules_global = [];
            col_modules_global = [];
            N_global = 0;

            for i = 1:S
               
                idx_rows = find(C_rows==i);
                idx_cols = find(C_cols==i);
                
                if(isempty(idx_rows) || isempty(idx_cols))
                    rows_empty = [rows_empty; idx_rows];
                    cols_empty = [cols_empty; idx_cols];
                    continue;
                end
                
                obj.matrix = matrix_global(idx_rows,idx_cols);
                [obj.n_rows obj.n_cols] = size(obj.matrix);
                obj.CalculateBBMatrix();
                if(sum(sum(obj.matrix))==numel(obj.matrix))
                    obj.AssignSingleModule();
                else
                    obj.DetectComponent();
                    %obj.AssignSingleModule();
                end
                rr_global(idx_rows,end+1:end+obj.N) = obj.rr;
                tt_global(idx_cols,end+1:end+obj.N) = obj.tt;
                try
                    row_modules_global(idx_rows) = obj.row_modules+N_global;
                catch
                    idx_rows
                    row_modules_global
                    obj.row_modules
                    N_global
                    matrix_global
                    save matrix_global;
                end
                col_modules_global(idx_cols) = obj.col_modules+N_global;
                N_global = N_global + obj.N;
                
            end
            obj.rr = rr_global;
            obj.tt = tt_global;
            obj.N = N_global;
            obj.row_modules = row_modules_global;
            obj.col_modules = col_modules_global;
            
            if(~isempty(rows_empty) || ~isempty(cols_empty))
                obj.rr(rows_empty,end+1) = 1;
                obj.tt(cols_empty,end+1) = 1;
                obj.N = obj.N+1;
                obj.row_modules(idx_rows) = obj.N;
                obj.col_modules(idx_cols) = obj.N;
            end
            
            obj.matrix = matrix_global;
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            obj.CalculateBBMatrix();
            obj.Qb = obj.CalculateQValue();
            obj.CalculateQrValue();
            obj.SortModules;
            
            obj.done = 1;
            
        end
        
        function obj = AssignSingleModule(obj)
            obj.N = 1;
            obj.rr = ones(obj.n_rows,1);
            obj.tt = ones(obj.n_cols,1);
            obj.row_modules = ones(1,obj.n_rows);
            obj.col_modules = ones(1,obj.n_cols);
        end
        
        function obj = AssignModules(obj)
            [a b] = ind2sub(size(obj.rr), find(obj.rr));
            [val sortv] = sort(a);
            obj.row_modules = b(sortv);
            
            [a b] = ind2sub(size(obj.tt), find(obj.tt));
            [val sortv] = sort(a);
            obj.col_modules = b(sortv);
        end
        
        function obj = CalculateBBMatrix(obj)
            if all(all(obj.matrix == 0))
                obj.bb = obj.matrix;
            else
                coldeg = sum(obj.matrix, 1);
                rowdeg = sum(obj.matrix, 2);
                %obj.n_edges = sum(rowdeg);
                obj.bb = obj.matrix - (1/obj.n_edges) * rowdeg * coldeg;
            end
        end
        

        function obj = SortModules(obj)
           
            if(obj.n_rows > obj.n_cols)
                [~,idx] = sort(sum(obj.rr),'descend');
            else
                [~,idx] = sort(sum(obj.tt),'descend');
            end
                        
            obj.index_rows = 1:obj.n_rows;
            obj.index_cols = 1:obj.n_cols;
            
            obj.rr = obj.rr(:,idx);
            obj.tt = obj.tt(:,idx);
            
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i));
                idx_cols = find(obj.tt(:,i));
                
                if(sum(sum(obj.matrix(idx_rows,:),2)==0) || sum(sum(obj.matrix(:,idx_cols),1))==0)
                    rr_temp = obj.rr(:,i);
                    tt_temp = obj.tt(:,i);
                    for j = i:obj.N-1
                        obj.rr(:,j) = obj.rr(:,j+1);
                        obj.tt(:,j) = obj.tt(:,j+1);
                    end
                    obj.rr(:,obj.N) = rr_temp;
                    obj.tt(:,obj.N) = tt_temp;
                    break;
                end
            end
            
            sorted_matrix = obj.matrix;
            
            row_global = []; col_global = [];
            for i = 1:obj.N
               
                row_i = find(obj.rr(:,i));
                col_i = find(obj.tt(:,i));
                
                [~,row_loc] = sort(sum(sorted_matrix(row_i,col_i),2),'descend');
                [~,col_loc] = sort(sum(sorted_matrix(row_i,col_i),1),'ascend');
                
                row_global = [row_global; row_i(row_loc)];
                col_global = [col_global; col_i(col_loc)];
                
            end
           
            col_global = flipud(col_global);
            obj.rr_sorted = obj.rr(row_global,:);
            obj.tt_sorted = obj.tt(col_global,:);
            
            obj.index_rows = row_global;
            obj.index_cols = col_global;
            
            %obj.row_modules = obj.row_modules(row_global);
            %obj.col_modules = obj.col_modules(col_global);
            [a b] = ind2sub(size(obj.rr_sorted), find(obj.rr_sorted));
            [val sortv] = sort(a);
            obj.row_modules = b(sortv);
            
            [a b] = ind2sub(size(obj.tt_sorted), find(obj.tt_sorted));
            [val sortv] = sort(a);
            obj.col_modules = b(sortv);
            
            
            
        end
        
        
        function q = CalculateQValue(obj)
            
            q = trace(obj.rr' * obj.bb * obj.tt) / obj.n_edges;
            
        end
        

        function obj = CalculateQrValue(obj)
           
            obj.Qr = 0;
            
            for i = 1:obj.N
                row_index = find(obj.rr(:,i));
                col_index = find(obj.tt(:,i));
                nr = length(row_index);
                nc = length(col_index);
                
                for j = 1:nr
                    for k = 1:nc
                        if(obj.matrix(row_index(j),col_index(k)) > 0)
                            obj.Qr = obj.Qr + 1;
                        end
                    end
                end
            end
            
            obj.Qr = obj.Qr / obj.n_edges;
        end
        
        
        function obj = CleanCommunities(obj)
           
            %CLEAN THE COMMUNITIES
            com1 = find(any(obj.tt));
            com2 = find(any(obj.rr));
            
            if(length(com1) >= length(com2)) %Not sure if this validation is necesarry.
                obj.rr = obj.rr(:,com1);
                obj.tt = obj.tt(:,com1);
            else
                obj.rr = obj.rr(:,com2);
                obj.tt = obj.tt(:,com2);
            end
            
            obj.N = size(obj.rr,2);
            
        end
       
        function matrices = ExtractCommunityMatrices(obj)
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.tt(:,i)==1);
                matrices{i} = obj.matrix(idx_rows,idx_cols);
            end 
        end
        
        function [module_rows module_cols] = ExtractCommunityIndexes(obj)
           
            module_rows = cell(obj.N,1);
            module_cols = cell(obj.N,1);
            for i = 1:obj.N
                
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.rr(:,i)==1);
                
                module_rows{i} = idx_rows;
                module_cols{i} = idx_cols;
                
            end
            
        end 
        
        function q = TestRowsContribution(obj,row_ids)
            q = trace(obj.rr(row_ids,:)' * obj.bb(row_ids,:) * obj.tt) / obj.n_edges;
        end
        
        function networks = ExtractCommunityModules(obj)
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.tt(:,i)==1);
                ma = obj.webmatrix(idx_rows,idx_cols);
                networks{i} = Bipartite(ma);
            end 
        end
        
    end
    
end