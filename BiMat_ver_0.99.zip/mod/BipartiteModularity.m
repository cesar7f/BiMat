% BipartiteModularity - Modularity parent class. 
% This class is the main part of all three bipartite modularity codes.
% It contains all the shared methods of the modularity algorithms.
% The way this class works is by isolating the graph (matrix) in
% independent connected components first, and find the best modularity
% configuration for each component. However, the modularity still try
% to maximize the global modularity.
%
% BipartiteModularity Properties:
%    matrix - Boolean Bipartite adjacency matrix
%    rr - Row community matrix. Size = n_rows*N
%    tt - Column community matrix. Size = n_cols*N
%    rr_sorted - rr sorted by community size (=rr(index_rows))
%    tt_sorted - tt sorted by community size (=tt(index_cols))
%    n_rows - Number of rows
%    n_cols - Number of columns
%    n_edges - Number of edges
%    bb - Original - Null (matrix - kidj/num_edges)
%    index_rows - Register of the swaps in Rows.
%    index_cols - Register of the swaps in Cols.
%    trials - Number of trials to find the best modularity configuration
%    Qb - Standard Modularity function (1/num_edges) * Trace(rr' * bb * tt)
%    Qr - Percentage of interactions inside modules
%    N  - Number of modules
%    row_modules - Module index for rows
%    col_modules - Module index for columns
%    done - The algorithm has been performed
%    webmatrix - Same than matrix but not neccesearly boolean.
%
%
% BipartiteModularity Methods:
%    AssignModules
%    AssignSingleModule
%    CalculateBBMatrix
%    CalculateQValue
%    CalculateQrValue
%    CleanCommunities
%    Detect
%    ExtractCommunityIndexes
%    ExtractCommunityMatrices
%    ExtractCommunityModules
%    SortModules
%    TestRowsContribution
%
% See also:
%    AdaptiveBrim, NewmanModularity, and LPBrim
classdef BipartiteModularity < handle

    properties
        matrix               = [];  %Boolean Bipartite adjacency matrix
        rr                   = [];  %Row community matrix. Size = n_rows*N
        tt                   = [];  %Column community matrix. Size = n_cols*N
        rr_sorted            = [];  %$$rr$$ sorted by community size (=rr(index_rows))
        tt_sorted            = [];  %tt sorted by community size (=tt(index_cols))
        n_rows               = 0;   %Number of rows
        n_cols               = 0;   %Number of columns
        n_edges              = 0;   %Number of edges
        bb                   = [];  %Original - Null (matrix - kidj/num_edges)
        index_rows           = [];  %Register of the swaps in Rows.
        index_cols           = [];  %Register of the swaps in Cols.
        trials               = 100; %Number of trials to find the best modularity configuration
        Qb                   = 0;   %Standard Modularity function (1/num_edges) * Trace(rr' * bb * tt)
        Qr                   = 0;   %Percentage of interactions inside modules
        N                    = 0;   %Number of modules
        row_modules          = [];  %Module index for rows
        col_modules          = [];  %Module index for columns
        done                 = 0;   %The algorithm has been performed
        webmatrix            = [];  %Same than matrix but not neccesearly boolean.
    end
    
    properties(Access = protected) %Used for calculating modularity in a single graph component
        matrix_component      = [];
        rr_component          = [];
        tt_component          = [];
        row_modules_component = [];
        col_modules_component = [];
        n_rows_component      = [];
        n_cols_component      = [];
        n_edges_component     = [];
        N_component           = [];
    end
        
    methods(Abstract)
        
        % DetectComponent - Abstract method to be implemented in all
        %    BipartiteModularity son classes
        % See AdaptiveBrim, NewmanModularity, and LPBrim
        obj = DetectComponent(obj);

    end
    
    methods(Access=protected)
        
        % BipartiteModularity(bipmatrix) - Main constructor
        %   It contains all the shared operations of the bipartite modularity algorithm
        %   constructors. Can be called only from a son class.
        % See AdaptiveBrim, NewmanModularity, and LPBrim
        function obj = BipartiteModularity(bipmatrix)
        
            obj.webmatrix = bipmatrix;
            obj.matrix = bipmatrix > 0;
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            
            obj.n_edges = sum(sum(obj.matrix));
            
        end
    
    end
    
    methods
        
        
        function obj = Detect(obj,ntrials)
        % obj = Detect(obj) - Main modularity detection method
        % This method calculate the modularity by first dividing the
        % network (matrix) in isolated components. The modularity is
        % optimized in each component separatly.. 
            
            if(nargin == 2)
                obj.trials = ntrials;
            end
            
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            
            %Divide the network in isolated graph components.
            mm = [zeros(obj.n_rows, obj.n_rows) obj.matrix; obj.matrix' zeros(obj.n_cols, obj.n_cols)];
            %S = number of components, C = component indexes.
            [S, C] = graphconncomp(sparse(mm),'Weak', true);
            
            %Assign component indexes to rows and column nodes.
            C_rows = C(1:obj.n_rows);
            C_cols = C(1+obj.n_rows:obj.n_rows+obj.n_cols);
            
            matrix_global = obj.matrix;
            
            %rows and column nodes that will belong to the community with
            %no interactions.
            rows_empty = [];
            cols_empty = [];
            
            %Community indexes for rows (rr) and columns(tt)
            rr_global = [];
            tt_global = [];
            index_rows_global = 1:obj.n_rows;
            index_cols_global = 1:obj.n_cols;
            row_modules_global = [];
            col_modules_global = [];
            N_global = 0;

            %For each component in the graph find the best modularity
            for i = 1:S
               
                %Locate the nodes that belongs to component i
                idx_rows = find(C_rows==i);
                idx_cols = find(C_cols==i);
                
                %if rows or columns nodes does not exist in component i, it
                %means that nodes are single nodes and therefore no
                %interaction exist. Add to the empty vector community.
                if(isempty(idx_rows) || isempty(idx_cols))
                    rows_empty = [rows_empty; idx_rows];
                    cols_empty = [cols_empty; idx_cols];
                    continue;
                end
                
                %Extract the component matrix from the entire matrix.
                obj.matrix = matrix_global(idx_rows,idx_cols);
                [obj.n_rows obj.n_cols] = size(obj.matrix);
                %Calculate the modularity matrix for the extracted matrix
                obj.CalculateBBMatrix();
                %If the matrix is not fully connected, proced to find the
                %best modularity distribution
                if(sum(sum(obj.matrix))~=numel(obj.matrix))
                    obj.DetectComponent();
                %otherwise assign the nodes to a single module
                else
                    obj.AssignSingleModule();
                    %obj.AssignSingleModule();
                end
                
                %Expand the global community indexes by the findings in the
                %current component.
                rr_global(idx_rows,end+1:end+obj.N) = obj.rr;
                tt_global(idx_cols,end+1:end+obj.N) = obj.tt;
                try
                    row_modules_global(idx_rows) = obj.row_modules+N_global;
                catch
                    idx_rows
                    row_modules_global
                    obj.row_modules
                    N_global
                    matrix_global
                    save matrix_global;
                end
                col_modules_global(idx_cols) = obj.col_modules+N_global;
                N_global = N_global + obj.N;
                
            end
            obj.rr = rr_global;
            obj.tt = tt_global;
            obj.N = N_global;
            obj.row_modules = row_modules_global;
            obj.col_modules = col_modules_global;
            
            if(~isempty(rows_empty) || ~isempty(cols_empty))
                obj.rr(rows_empty,end+1) = 1;
                obj.tt(cols_empty,end+1) = 1;
                obj.N = obj.N+1;
                obj.row_modules(idx_rows) = obj.N;
                obj.col_modules(idx_cols) = obj.N;
            end
            
            obj.matrix = matrix_global;
            [obj.n_rows obj.n_cols] = size(obj.matrix);
            obj.n_edges = sum(obj.matrix(:));
            obj.CalculateBBMatrix();
            obj.Qb = obj.CalculateQValue();
            obj.CalculateQrValue();
            obj.SortModules;
            
            obj.done = 1;
            
        end
        
        function obj = AssignSingleModule(obj)
        % AssignSingleModule(obj)
        % Assign all the nodes to a single module.
        
            obj.N = 1;
            obj.rr = ones(obj.n_rows,1);
            obj.tt = ones(obj.n_cols,1);
            obj.row_modules = ones(1,obj.n_rows);
            obj.col_modules = ones(1,obj.n_cols);
        end
        
        function obj = AssignModules(obj)
        % obj = AssignModules(obj)
        % Find the module indexes for each row and colum
        
            [a b] = ind2sub(size(obj.rr), find(obj.rr));
            [val sortv] = sort(a);
            obj.row_modules = b(sortv);
            
            [a b] = ind2sub(size(obj.tt), find(obj.tt));
            [val sortv] = sort(a);
            obj.col_modules = b(sortv);
        end
        
        function obj = CalculateBBMatrix(obj)
        % CalculateBBMatrix(obj)
        % Calculate the modularity matrix.
        
            if all(all(obj.matrix == 0))
                obj.bb = obj.matrix;
            else
                coldeg = sum(obj.matrix, 1);
                rowdeg = sum(obj.matrix, 2);
                %obj.n_edges = sum(rowdeg);
                obj.bb = obj.matrix - (1/obj.n_edges) * rowdeg * coldeg;
            end
        end
        
        function obj = SortModules(obj)
        % obj = SortModules(obj)
        % Method using for finding the adecuate sorting of rows and columns
        % according to the module that they belong to. This method is
        % mainly used for plotting modular graph and matrix plots.
            
            %Sort by module row or column size.
            if(obj.n_rows > obj.n_cols)
                [~,idx] = sort(sum(obj.rr),'descend');
            else
                [~,idx] = sort(sum(obj.tt),'descend');
            end
               
            %Initial indexing is according in ascending order 1,2,3,...
            obj.index_rows = 1:obj.n_rows;
            obj.index_cols = 1:obj.n_cols;
            
            %Sort module index matrices
            obj.rr = obj.rr(:,idx);
            obj.tt = obj.tt(:,idx);
            
            %For each module, sort according to a nested configuration.
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i));
                idx_cols = find(obj.tt(:,i));
                
                if(sum(sum(obj.matrix(idx_rows,:),2)==0) || sum(sum(obj.matrix(:,idx_cols),1))==0)
                    rr_temp = obj.rr(:,i);
                    tt_temp = obj.tt(:,i);
                    for j = i:obj.N-1
                        obj.rr(:,j) = obj.rr(:,j+1);
                        obj.tt(:,j) = obj.tt(:,j+1);
                    end
                    obj.rr(:,obj.N) = rr_temp;
                    obj.tt(:,obj.N) = tt_temp;
                    break;
                end
            end
            
            sorted_matrix = obj.matrix;
            
            row_global = []; col_global = [];
            %For each module, sort according to a nested configuration.
            for i = 1:obj.N
               
                row_i = find(obj.rr(:,i));
                col_i = find(obj.tt(:,i));
                
                [~,row_loc] = sort(sum(sorted_matrix(row_i,col_i),2),'descend');
                [~,col_loc] = sort(sum(sorted_matrix(row_i,col_i),1),'ascend');
                
                row_global = [row_global; row_i(row_loc)];
                col_global = [col_global; col_i(col_loc)];
                
            end
           
            col_global = flipud(col_global);
            obj.rr_sorted = obj.rr(row_global,:);
            obj.tt_sorted = obj.tt(col_global,:);
            
            obj.index_rows = row_global;
            obj.index_cols = col_global;
            
            %obj.row_modules = obj.row_modules(row_global);
            %obj.col_modules = obj.col_modules(col_global);
            [a b] = ind2sub(size(obj.rr_sorted), find(obj.rr_sorted));
            [val sortv] = sort(a);
            obj.row_modules = b(sortv);
            
            [a b] = ind2sub(size(obj.tt_sorted), find(obj.tt_sorted));
            [val sortv] = sort(a);
            obj.col_modules = b(sortv);
            
            
            
        end
        
        function q = CalculateQValue(obj)
        % obj = CalculateQValue(obj)
        % Calculaate the standard bipartite modularity
        % Q = (1/m) Tr (R' B T)
        % Value in the range 0-1 with a maximal possible value of
        % 1-fill(connectance).    
            q = trace(obj.rr' * obj.bb * obj.tt) / obj.n_edges;
            
        end
        
        
        function obj = CalculateQrValue(obj)
        % obj = CalculateQrValue(obj)
        % Calculated the fraction of of interactions that fall inside
        % modules. The bigger the value, the bigger
        % the fraction of interactions that falls inside modules. Value in
        % the range (0,1).
        
            obj.Qr = 0;
            
            for i = 1:obj.N
                row_index = find(obj.rr(:,i));
                col_index = find(obj.tt(:,i));
                nr = length(row_index);
                nc = length(col_index);
                
                for j = 1:nr
                    for k = 1:nc
                        if(obj.matrix(row_index(j),col_index(k)) > 0)
                            obj.Qr = obj.Qr + 1;
                        end
                    end
                end
            end
            
            obj.Qr = obj.Qr / obj.n_edges;
        end
        
        
        function obj = CleanCommunities(obj)
        % obj = CleanCommunities(obj)
        % Sometimes it may happen that there are more columns in the
        % matrix modules than modules. When that happens, this function
        % will clean (delete) the empty columns.   
            
            com1 = find(any(obj.tt));
            com2 = find(any(obj.rr));
            
            if(length(com1) >= length(com2)) %Not sure if this validation is necesarry.
                obj.rr = obj.rr(:,com1);
                obj.tt = obj.tt(:,com1);
            else
                obj.rr = obj.rr(:,com2);
                obj.tt = obj.tt(:,com2);
            end
            
            obj.N = size(obj.rr,2);
            
        end
       
        function matrices = ExtractCommunityMatrices(obj)
        % obj = ExtractCommunityMatrices(obj)
        % This method will return a cell array with N matrices, where N is
        % the number of modules. Each matrix i will be composed of only the
        % row and column nodes that belong to the module i.
        
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.tt(:,i)==1);
                matrices{i} = obj.matrix(idx_rows,idx_cols);
            end 
        end
        
        function [module_rows module_cols] = ExtractCommunityIndexes(obj)
        % obj = ExtractCommunityMatrices(obj)
        % This method will return two cell arrays with N matrices, where N is
        % the number of modules. Each cell array will have a the index
        % number (row/column id) of the row/columns that belongs to module
        % i.
            module_rows = cell(obj.N,1);
            module_cols = cell(obj.N,1);
            for i = 1:obj.N
                
                %Find the row and column indexes that belongs to module i
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.rr(:,i)==1);
                
                module_rows{i} = idx_rows;
                module_cols{i} = idx_cols;
                
            end
            
        end 
        
        function q = TestRowsContribution(obj,row_ids)
        %Untested function
            q = trace(obj.rr(row_ids,:)' * obj.bb(row_ids,:) * obj.tt) / obj.n_edges;
        end
        
        function networks = ExtractCommunityModules(obj)
        % networks = ExtractCommunityModules(obj)
        % This method will return a cell array with N Bipartite objects, where N is
        % the number of modules. Each bipartite object i will be composed of only the
        % row and column nodes that belong to the module i.
            for i = 1:obj.N
                idx_rows = find(obj.rr(:,i)==1);
                idx_cols = find(obj.tt(:,i)==1);
                ma = obj.webmatrix(idx_rows,idx_cols);
                networks{i} = Bipartite(ma);
            end 
        end
        
    end
    
end