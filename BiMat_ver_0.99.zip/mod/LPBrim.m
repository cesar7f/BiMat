%==========================================================================
% Name        : LPBrim.m
% Author      : Cesar Flores
% Created     : 23/Jan/2012
% Updated     : 23/Jan/2012
% Description : Represents the LP&BRIM algorithm 
%==========================================================================
%              

classdef LPBrim < BipartiteModularity
    % LPBrim Main code class. 
    % LPBrim algorithm that may work better than the adaptive brim version
    % for large scale bipartite networks.
    %
    % LPBrim Properties:
    %    red_labels - Works as module identifiers for rows
    %    blue_labels - Works as module identifiers for columns
    %
    % LPBrim Methods:
    %    LPBrim - Main constructor    
    %    DetectComponent - Detect the modularity in a single component of
    %    the network
    %
    % See BipartiteModularity.
    
    properties%(GetAccess = 'private', SetAccess = 'private')
        red_labels           = 0; %Works as module identifiers for rows
        blue_labels          = 0; %Works as module identifiers for columns
    end
    
    %CONSTRUCTOR AND MAIN PROCEDURES ALGORITHM
    methods
        
        function obj = LPBrim(bipmatrix)
        % obj = LPBrim(bipmatrix) - Main constructor
            
            %Call the parent class    
            obj = obj@BipartiteModularity(bipmatrix);
           
        end
        
        function obj = DetectComponent(obj)
        % obj = DetectComponent(obj) - Detect the modularity in a specific
        % component.
            
            %Apply the LP algorithm
            obj.LP();
            
            %Tunne the result by applying the BRIM algorithm in the found
            %configuration.
            obj.BRIM();
            
            %Clean empty rows and columns in the module matrices.
            obj.CleanCommunities();
            
            %obj.CalculateQrValue();
            
            %Assign module index to each row and column node.
            obj.AssignModules();
            
            %obj.SortModules;
            
            
            
        end
            
    end
    
    methods
       
       
        function obj = LP(obj)
            
            %Find the initial maximal number of modules.
            cmax = max(obj.n_rows,obj.n_cols);
            
            %Create your module matrices with the appropiate size.
            obj.rr = zeros(obj.n_rows,cmax);
            obj.tt = zeros(obj.n_cols,cmax);
            
            %Assign each node in the module matrices to different module (column).
            obj.rr(1:obj.n_rows,1:obj.n_rows) = eye(obj.n_rows);
            obj.tt(1:obj.n_cols,1:obj.n_cols) = eye(obj.n_cols);
            
            obj.n_edges = sum(sum(obj.matrix));
            
            %Calculate the initial modularity the previous configuration
            qmax = obj.CalculateQValue();
            
            %Keep the current configuration as the best one so far
            qmaxglobal = qmax;
            ttMaxGlobal = obj.tt;
            rrMaxGlobal = obj.rr;
            
            %Repeat for obj.trials the algorithm and always keep the best
            %one
            for j = 1:obj.trials
                
                %Fin the maximal number of modules.
                cmax = max(obj.n_rows,obj.n_cols);
                
                %Assign the LP module indexes (each row and column node in
                %a independen module).
                obj.red_labels = 1:obj.n_rows;
                obj.blue_labels = 1:obj.n_cols;
                
                %Create your module matrices with the appropiate size and
                %assign each node to different module
                obj.rr = zeros(obj.n_rows,cmax);
                obj.tt = zeros(obj.n_cols,cmax);
                obj.rr(1:obj.n_rows,1:obj.n_rows) = eye(obj.n_rows);
                obj.tt(1:obj.n_cols,1:obj.n_cols) = eye(obj.n_cols);
                qmax = obj.CalculateQValue();
                rrMax = obj.rr;
                ttMax = obj.tt;
                
                %LP BRIM main algorithm part
                while(1)

                    %Propagate red labels to blue labels
                    for i = 1:obj.n_cols
                        neighbors = obj.matrix(:,i);
                        labels = obj.red_labels(neighbors);
                        uniq = unique(labels);
                        nuniq = length(uniq);
                        rperm = randperm(nuniq);
                        uniq = uniq(rperm);
                        count = arrayfun(@(x) sum(x==labels), uniq);
                        [maxv index] = max(count);
                        if(~isempty(uniq(index)))
                            obj.blue_labels(i) = uniq(index);
                        end
                    end

                    uniq = unique(obj.blue_labels);
                    nbluec = length(uniq);
                    newlab = arrayfun(@(x) find(uniq==x), obj.blue_labels);
                    obj.blue_labels = newlab;

                    %Propagate blue labels to red labels
                    for i = 1:obj.n_rows
                        neighbors = obj.matrix(i,:);
                        labels = obj.blue_labels(neighbors);
                        uniq = unique(labels);
                        nuniq = length(uniq);
                        rperm = randperm(nuniq);
                        uniq = uniq(rperm);
                        count = arrayfun(@(x) sum(x==labels), uniq);
                        [maxv index] = max(count);
                        if(~isempty(uniq(index)))
                            obj.red_labels(i) = uniq(index);
                        end
                    end

                    uniq = unique(obj.red_labels);
                    nredc = length(uniq);
                    newlab = arrayfun(@(x) find(uniq==x), obj.red_labels);
                    obj.red_labels = newlab;

                    cmax = max(nbluec, nredc);
                    indxblue = sub2ind([obj.n_cols cmax], 1:obj.n_cols, obj.blue_labels);
                    indxred = sub2ind([obj.n_rows cmax], 1:obj.n_rows, obj.red_labels);

                    obj.rr = zeros(obj.n_rows,cmax);
                    obj.tt = zeros(obj.n_cols,cmax);
                    obj.rr(indxred) = 1;
                    obj.tt(indxblue) = 1;

                    q = obj.CalculateQValue();
                    
                    %If the modularity configuration is better than the
                    %current one, replace it. Otherwise exit the LP loop.
                    if(q > qmax) 
                        qmax = q;
                        rrMax = obj.rr;
                        ttMax = obj.tt;
                    else
                        break;
                    end

                end
                
                %If the LP configuration found in trial i is better than
                %the global configuration replace the global with it.
                if(qmax > qmaxglobal)
                    qmaxglobal = qmax;
                    rrMaxGlobal = rrMax;
                    ttMaxGlobal = ttMax;
                end
            end
            
            %Assign the values found to the standart class variables.
            obj.Qb = qmaxglobal;
            obj.rr = rrMaxGlobal;
            obj.tt = ttMaxGlobal;
        end
        
        function obj = BRIM(obj)
        % obj = BRIM(obj) - Perform an standard BRIM algorithm in which the
        % module matrix rr (R) is assigned according to B*T and the
        % module matrix tt (T) is assigned using B'*T.
            
            inducingBlueFlag = 1;
            obj.n_edges = sum(obj.matrix(:));
            
            preQ = obj.CalculateQValue();
            while(1)
               
                if(inducingBlueFlag)
                    obj.AssignBlueNodes();
                else
                    obj.AssignRedNodes();
                end
                
                newQ = obj.CalculateQValue();
                
                if(newQ <= preQ)
                    break;
                else
                    preQ = newQ;
                    inducingBlueFlag = ~inducingBlueFlag;
                end
                
            end
        end
        

        function obj = AssignRedNodes(obj)
        % obj = AssignRedNodes(obj) - Create module matrix rr (R) using B*T
            try 
                [maxval, maxind] = max(obj.bb*obj.tt, [], 2);
                modules = eye(size(obj.tt,2));
                obj.rr = modules(maxind, :);
            catch
                display('FATAL ERROR');
            end
            
        end
        
        function obj = AssignBlueNodes(obj)
        % obj = AssignBlueNodes(obj) - Create module matrix tt (T) using
        % B'*T
            try
                [maxval, maxind] = max(obj.bb'*obj.rr, [], 2);
                modules = eye(size(obj.rr,2));
                obj.tt = modules(maxind, :);
            catch
                display('FATAL ERROR');
            end
            
        end
        

        
    end
    
end