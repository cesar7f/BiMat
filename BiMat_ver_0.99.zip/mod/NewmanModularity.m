classdef NewmanModularity < BipartiteModularity
    % NewmanModularity Main code class. 
    % Newman famous algorithm to calculate modularity in unipartite
    % networks. In this case, the bipartite component is converted to
    % unipartite and then, the Newman algorithm is applied.
    %
    % NemanModularity Properties:
    %    adjacency - Unipartite version of the adjacency matrix
    %    n_nodes - n_cols + n_rows
    %    pp - Null model matrix
    %    kk - Node Degrees
    %    ss - Community indices of the unipartite version
    %    DoKernighanLinTunning - Do a final tuning in the modularity configuration to improve the results.
    %    Q - Modularity value in uniparte version.
    %
    % NewmanModularity Methods:
    %    NewmanModularity - Main constructor    
    %    DetectComponent - Detect the modularity in a single component of
    %    the network
    %
    % See BipartiteModularity
    
    
    properties
        adjacency            = [];  %Unipartite version of the adjacency matrix
        n_nodes              = 0;   %n_cols + n_rows
        pp                   = [];  %Null model matrix
        kk                   = 0;   %Node Degrees
        ss                   = 0;   %Community indices of the unipartite version
        DoKernighanLinTunning= 1;   %Do a final tuning in the modularity configuration to improve the results.
        Q                    = 1;   %Modularity value in uniparte version.
    end
    
    methods
       
        function obj = NewmanModularity(bipmatrix)
        % obj = NewmanModularity(bipmatrix) - Main constructor
            
            %Call the parent class
            obj = obj@BipartiteModularity(bipmatrix);
            
        end
        
        function obj = DetectComponent(obj)
        % obj = DetectComponent(obj) - Detect the modularity in a specific
        % component.
        
            %Convert the bipartite matrix component to unipartite version.
            obj.adjacency = [zeros(obj.n_rows) obj.matrix; obj.matrix' zeros(obj.n_cols)];
            %obj.adjacency = bipmatrix > 0; %Uncomment if you want to work directly with unipartite networks
            
            %Get the number of total nodes, degrees and number of edges
            obj.n_nodes = size(obj.adjacency,1);
            obj.kk = sum(obj.adjacency,2);
            obj.n_edges_component = sum(obj.kk)/2;
            
            %If there is no interaction, the modular matrix is the same
            %than the adjacency matrix
            if all(all(obj.matrix == 0))
                obj.bb = obj.adjacency;
            %otherwise calculate the modular matrix using the unipartite
            %version equation
            else
                obj.bb = obj.adjacency - (obj.kk*obj.kk')/(2*obj.n_edges_component);
            end
            
            %Run the newman algorithm.
            obj.NewmanAlgorithm();
            ncom = length(unique(obj.ss));
            
            obj.rr = zeros(obj.n_rows,ncom);
            obj.tt = zeros(obj.n_cols,ncom);
            
            for i = 1:obj.n_nodes
                if(i <= obj.n_rows); obj.rr(i,obj.ss(i)) = 1;
                else obj.tt(i-obj.n_rows,obj.ss(i)) = 1; end;
            end
            
            obj.CleanCommunities();
            
            obj.AssignModules();
        end
        
        function obj = NewmanAlgorithm(obj)
        % obj = NewmanAlgorithm(obj) - Detect the modularity using Newman
        % algorithm.
            
            %Start with a single component.
            obj.N = 1;
            obj.Q = 0;
            
            %Community indexes of all nodes correspond to module 1.
            obj.ss = ones(obj.n_nodes,1);
            
            %Try to divide all the existing modules while increase in Q is
            %detected.
            qinc = 1;
            while(qinc == 1)
                   
                qinc = 0;
                nn = obj.N;
                
                %For each of the current modules, divide them only if
                %increase in Q is detected.
                for i = 1:nn
                    
                    %Get from the modular matrix the nodes that correspond
                    %to module i and find a new local modular matrix.
                    nindices = find(obj.ss==i);
                    nsize = length(nindices);
                    blocal = obj.bb(nindices,nindices);
                    blocal(1:nsize+1:end) = blocal(1:nsize+1:end)' - sum(blocal,2);
                    
                    %Use the biggest eigenvalue vector of the local matrix
                    %to divide the module in two.
                    [evec eval] = eig(blocal);
                    eval = diag(eval);
                    [meval maxindex] = max(eval);
                    evecmax = evec(:,maxindex);
                    
                    sslocal = ones(nsize,1);
                    sslocal(evecmax<=0) = -1;
                    
                    %Do a final tuning to improve the modularity
                    %configuration.
                    if(obj.DoKernighanLinTunning)
                        sslocal = obj.KernighanLin(sslocal,blocal);
                    end
                    
                    %Calculate the improvement in Q if module i is divided
                    %in two.
                    deltaQ = (sslocal' * blocal * sslocal) / (4*obj.n_edges_component);
                    
                    %If improvement is detected, divide the module in two,
                    %otherwise reject the division.
                    if(deltaQ > 0.000001)
                        qinc = 1;
                        newind = sslocal==1;
                        obj.ss(nindices(newind)) = obj.N+1;
                        obj.N = obj.N+1;
                        obj.Q = deltaQ + obj.Q;
                    end
                    
                end
                
            end
            
        end
        
        function ssnew = KernighanLin(obj,ss,blocal)
        % obj = KernighanLin(obj,ss,blocal) - Improve the modularity
        % configuration by applying KernighanLin algorithm. The idea of
        % this algorithm is just swapping always one node from one module
        % to the other such that it will be the best increase in
        % modularity. At each step the module which swapping gives the
        % biggest increase in modularity is swapped and the process
        % continue as long as modularity increase.
        
            %Calculate the modularity of a two module local network.
            nn = length(ss);
            ss_states = cell(nn+1,1);
            qglobal = obj.ModularityTwo(ss,blocal);
            
            qinc = 1;
            
            %Repeat while increase in modularity Q is detected.
            while(qinc == 1)
                
                qinc = 0;
                ss_states{1} = ss;
                q_values = zeros(nn,1);
                moved = zeros(nn,1);
                
                for i = 1:nn   

                    sslocal = ss_states{i};
                    qloc = -10;
                    for j = 1:nn

                        if(moved(j) == 1); continue; end;

                        sslocal(j)  = sslocal(j) * -1;
                        newq = obj.ModularityTwo(sslocal,blocal);

                        if(newq > qloc)
                            qindex = j;
                            qloc = newq;
                        end
                        sslocal(j)  = sslocal(j) * -1;

                    end
                    sslocal(qindex) = sslocal(qindex) * -1;
                    ss_states{i+1} = sslocal;
                    moved(qindex) = 1;
                    q_values(i) = qloc; 
                end
                
                [max_q max_state] = max(q_values);
                
                if(max_q > qglobal)
                    qglobal = max_q;
                    ss = ss_states{max_state+1};
                    qinc = 1;
                end
            end
            
            ssnew = ss;
            
        end
        
        function qq = ModularityTwo(obj,ss,bb)
        %qq = ModularityTwo(obj,ss,bb) gives the modularity value of a two
        %module unipartite network where ss is the module index using 1 and
        %-1 to distinwish between the two modules and bb is the modular
        %matrix.
            qq = (ss'*bb*ss) / (4*obj.n_edges_component);
        end
        
        function qq = Modularity(obj,ss,bb)
        %qq = Modularity(obj,ss,bb) Get the modularity of a unipartite
        %network using ss as module indesing and bb as modular matrix.
            ncom = length(unique(ss));
            nn = length(bb);
            S = zeros(nn,ncom);
            for i = 1:nn
                S(i,ss(i)) = 1;
            end
            qq = trace(S'*bb*S) / (2*obj.n_edges_component);
        end
        
    end
    
end