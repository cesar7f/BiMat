function [nodf nodf_rows nodf_cols] = NODF(matrix, nodf_strict)
% NODF - Calculate normalized nodf value of a matrix
%   [nodf nodf_rows nodf_cols] = NODF(matrix) - Calculate the normalized nodf
%   value for rows+columns (nodf), rows (nodf_rows), and columns (nodf_cols)
%   of matrix forcing an strict decreasing filling.
%
%   [nodf nodf_rows nodf_cols] = NODF(matrix,nodf_strict) - Calculate the normalized nodf
%   value for rows+columns (nodf), rows (nodf_rows), and columns (nodf_cols)
%   of matrix forcing an strict decreasing filling nodf_stric=1 or counting
%   equal degree rows/columns as nested nodf_strict=0.
%
%   Implemented by Gabriel Mitchell (not.i.said.the.fox@gmail.com)
    
    if(nargin==2 && nodf_strict==0)
       
        [n_rows n_cols] = size(matrix);
        nest_rows = 0;
        nest_cols = 0;
        deg_rows = sum(matrix,2);
        deg_cols = sum(matrix,1);
        for ii = 1:n_rows
            for jj = ii+1:n_rows
                nest_rows = nest_rows + sum(matrix(ii,:).*matrix(jj,:))/min(deg_rows(ii),deg_rows(jj));
            end
        end
        for ii = 1:n_cols
            for jj = ii+1:n_cols
                nest_cols = nest_cols + sum(matrix(:,ii).*matrix(:,jj))/min(deg_cols(ii),deg_cols(jj));
            end
        end
        
        nest_rows(isnan(nest_rows)) = 0;
        nest_cols(isnan(nest_cols)) = 0;
        
        denom = n_rows*(n_rows-1)/2 + n_cols*(n_cols-1)/2;
        nodf.nodf_rows = 100*nest_rows/(n_rows*(n_rows-1)/2);
        nodf.nodf_cols = 100*nest_cols/(n_cols*(n_cols-1)/2);   
        nodf.nodf = (nest_rows+nest_cols)/denom;

    else

        [n_rows n_cols] = size(matrix);

        C1 = (1.0*matrix)*matrix';
        D1 = repmat(diag(C1),1,n_rows);
        nr = (D1~=D1');%
        nr = C1.*nr;
        nr = nr./(min(D1,D1'));
        %nr = (C1-eye(size(C1)))./(min(D1,D1'));

        C2 = (1.0*matrix')*matrix;
        D2 = repmat(diag(C2),1,n_cols);
        nc = C2.*(D2~=D2');
        nc = nc./(min(D2,D2'));

        nr = nansum(nr(:))/2;
        nc = nansum(nc(:))/2;
        nvalue = nr+nc;

        denom = n_rows*(n_rows-1)/2 + n_cols*(n_cols-1)/2;
        nr = nr/(n_rows*(n_rows-1)/2);
        nc = nc/(n_cols*(n_cols-1)/2);   
        nvalue = nvalue/denom;

        nodf.nodf_rows = nr;
        nodf.nodf_cols = nc;
        nodf.nodf = nvalue;

    end
    
    
    if(nargout==2)
        nodf_rows = nodf.nodf_rows;
        nodf = nodf.nodf;
    elseif(nargout == 3)
        nodf_rows = nodf.nodf_rows;
        nodf = nodf.nodf;
        nodf_cols = nodf.nodf_cols;
    end
end