% MATLAB
%
% Files
%   Bipartite                     - Bipartite Main code class. 
%   matlab_example_sullivan_group - Add the code to the matlab path
%   matlab_example_yongmin_cho    - Add the code to the matlab path
