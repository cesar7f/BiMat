% Test Statistical analysis class for a bipartite object in terms of
% modularity and nestedness
%
% Test Properties:
%     bipweb - A bipartite network object in which the analysis will be done
%     nulls - A set of random matrices used as null model
%     tempvals - Results for the NTC value
%     eigvals - Results for the espectral Radius algorithm value
%     nestvals - Results for the NODF algorithm value
%     nestvals_rows - Results for the NODF algorithm in rows
%     nestvals_cols - Results for the NODF algorithm in columns
%     qb_vals - Results for the standard modularity value
%     qr_vals - Results for the ratio of interactions inside modules
%     nest_row_contrib - Row NODF contributions
%     nest_col_contrib - Column Nodf Contributions
%     model - Null Model that will be used for creating the random networks nulls
%     replicates - Number of random networks used for the null model
%     modul_done - The analysis in modularity was performed
%     nest_done - The analysis in NODF was performed
%     temp_done - The analysis in NTC was performed
%     eig_done - The analysis en expectral radius was performed
%     nest_contrib_done - The analysis on nestedness contribution was performed
%     print_output - Flag to print output       
%
% Test Methods:
%     Test - Main Constructor
%     DoNulls - Create random matrices for the statistical analysis
%     DoCompleteAnalysis - Perform the entire modularity and nestedness analysis
%     Nestedness - Perform the NODF Statistical Analysis
%     Temperature - Perform the NTC Statistical Analysis
%     MaxEigenvalue - Perform the spectral radius Statistical Analysis
%     Modularity - Perform the Modularity Statistical Analysis
%     NestednessContributions - Perform the nestedness contribution Statistical Analysis
%     GET_DEV_MODUL - Perform a Modularity Statistical Analysis
%     GET_DEV_NEST - Perform a NODF Statistical Analysis
%     GET_DEV_TEMP - Perform a NTC Statistical Analysis
%     GET_DEV_EIG - Perform a spectral radius Statistical Analysis
%     GET_NEST_CONTRIBUTIONS - Get NODF nestedness contributions of a
%
% See also:
%     BipartiteModularity, NODF, NestednessBINMATNEST
classdef Test < handle

    properties(GetAccess = 'public', SetAccess = 'public')
        bipweb       = {};     % A bipartite network object in which the analysis will be done
        nulls        = {};     % A set of random matrices used as null model
        tempvals      = [];    % Results for the NTC value
        eigvals       = [];    % Results for the espectral Radius algorithm value
        nestvals      = [];    % Results for the NODF algorithm value
        nestvals_rows = [];    % Results for the NODF algorithm in rows
        nestvals_cols = [];    % Results for the NODF algorithm in columns
        qb_vals       = [];    % Results for the standard modularity value
        qr_vals       = [];    % Results for the ratio of interactions inside modules
        nest_row_contrib = []; % Row NODF contributions
        nest_col_contrib = []; % Column Nodf Contributions
        model        = {};     % Null Model that will be used for creating the random networks nulls
        replicates   = 100;    % Number of random networks used for the null model
        modul_done   = 0;      % The analysis in modularity was performed
        nest_done    = 0;      % The analysis in NODF was performed
        temp_done    = 0;      % The analysis in NTC was performed
        eig_done     = 0;      % The analysis en expectral radius was performed
        nest_contrib_done = 0; % The analysis on nestedness contribution was performed
        print_output = 1;      % Flag to print output
    end
    
    methods

        function obj = Test(webbip)
        % Test - Main Constructor
        %   obj = TEST(webbip) Create a Test object that makes
        %   reference to the Bipartite object webbip
        
            obj.bipweb = webbip;
        end
        
        function obj = DoNulls(obj,nullmodel,replic)
        % DoNulls - Create random matrices for the statistical analysis
        %   obj = DoNulls(obj) Create 100 random matrices using the
        %   EQUIPROBABLE null model.
        %
        %   obj = DoNulls(obj,nullmodel) Create 100 random matrices using the
        %   indicated Null Model
        %
        %   obj = DoNulls(obj,nullmodel,replic) Create replic random
        %   matrices using the null model indicated in the variable
        %   nullmodel
        
            obj.modul_done = 0;
            obj.nest_done = 0;
            
            if(nargin == 1)
                obj.model = @NullModels.EQUIPROBABLE;
                obj.replicates = 100;
            elseif(nargin == 2)
                obj.model = nullmodel;
                obj.replicates = 100;
            else
                obj.model = nullmodel;
                obj.replicates = replic;
            end
            
            obj.nulls = NullModels.NULL_MODEL(obj.bipweb.adjacency,obj.model,obj.replicates);
            
        end
        
        function obj = DoCompleteAnalysis(obj, replic, nullmodel)
        % DoCompleteAnalysis - Perform the entire modularity and nestedness analysis
        %   obj = DoCompleteAnalysis(obj) Perform the entire analysis for
        %   nestedness and modularity using the EQUIPROBABLE null model and 100 random matrices.
        %
        %   obj = DoCompleteAnalysis(obj,replic) Perform the entire analysis for
        %   nestedness and modularity using the EQUIPROBABLE null model and a total of replic random matrices.
        %
        %   obj = DoCompleteAnalysis(obj,replic,nullmodel) Perform the entire analysis for
        %   nestedness and modularity using the the specified Null model
        %   and a total of replic random matrices
        
            
            if(nargin == 1)
                nullmodel= @NullModels.EQUIPROBABLE;
                replic = 100;
            elseif(nargin == 2)
                nullmodel= @NullModels.EQUIPROBABLE;
            end
            
            obj.DoNulls(nullmodel,replic);
            obj.Nestedness();
            obj.Modularity();
            obj.Temperature();
            %obj.MaxEigenvalue();
            
            if(obj.print_output == 1)
                fprintf('Null Model: %s\n', func2str(obj.model));
                fprintf('Trials: %i\n', replic);
                fprintf('Modularity\n');
                fprintf('\tQb: %f\n', obj.qb_vals.value);
                fprintf('\tz-score: %f\n', obj.qb_vals.zscore);
                fprintf('\tpercentage: %f\n', obj.qb_vals.percent);
                fprintf('Nestedness\n');
                fprintf('\tNodf: %f\n', obj.nestvals.value);
                fprintf('\tz-score: %f\n', obj.nestvals.zscore);
                fprintf('\tpercentage: %f\n', obj.nestvals.percent);
                fprintf('Temperature\n');
                fprintf('\tNTC: %f\n', obj.tempvals.ntc);
                fprintf('\tz-score: %f\n', obj.tempvals.zscore);
                fprintf('\tpercentage: %f\n', obj.tempvals.percent);
                %fprintf('Eigenvalue Nestedness\n');
                %fprintf('\tMax Eigenvalue: %f\n', obj.eigvals.maxe);
                %fprintf('\tz-score: %f\n', obj.eigvals.zscore);
                %fprintf('\tpercentage: %f\n', obj.eigvals.percent);
            end
            
        end
        
        function obj = Nestedness(obj)
        % Nestedness - Perform the NODF Statistical Analysis
        %   obj = Nestedness(obj) Perform the entire NODF analsysis. Be
        %   sure to create the random matrices before calling this
        %   function. Otherwise only 100 equiprobable random matrices will
        %   be used for the analysis
        
            if(isempty(obj.nulls))
                obj.DoNulls();
            end
            [obj.nestvals obj.nestvals_rows obj.nestvals_cols] = Test.GET_DEV_NEST(obj.bipweb,obj.nulls);
            obj.nest_done = 1;
            
        end
        
        function obj = Temperature(obj)
        % Temperature - Perform the NTC Statistical Analysis
        %   obj = Temperature(obj) Perform the NTC Statistical analsysis. Be
        %   sure to create the random matrices before calling this
        %   function. Otherwise only 100 equiprobable random matrices will
        %   be used for the analysis
        
            if(isempty(obj.nulls))
                obj.DoNulls();
            end
            [obj.tempvals] = Test.GET_DEV_TEMP(obj.bipweb,obj.nulls);
            obj.temp_done = 1;
        end
        
        function obj = MaxEigenvalue(obj)
        % MaxEigenvalue - Perform the spectral radius Statistical Analysis
        %   obj = MaxEigenvalue(obj) Perform the NTC Statistical analsysis. Be
        %   sure to create the random matrices before calling this
        %   function. Otherwise only 100 equiprobable random matrices will
        %   be used for the analysis
            
            if(isempty(obj.nulls))
                obj.DoNulls();
            end
            
            [obj.eigvals] = Test.GET_DEV_EIG(obj.bipweb,obj.nulls);
            
            obj.eig_done = 1;
        end
        
        function obj = Modularity(obj)
        % Modularity - Perform the Modularity Statistical Analysis
        %   obj = Temperature(obj) Perform the NTC Statistical analsysis. Be
        %   sure to create the random matrices before calling this
        %   function. Otherwise only 100 equiprobable random matrices will
        %   be used for the analysis
        
            if(isempty(obj.nulls))
                obj.DoNulls();
            end
            
            %Calculate the modularity of the Bipartite object
            if(obj.bipweb.modules.done == 0)
                obj.bipweb.modules.Detect(100);
            end
            
            [obj.qb_vals obj.qr_vals] = Test.GET_DEV_MODUL(obj.bipweb, obj.nulls);
            obj.modul_done = 1;
        end
        
        function obj = NestednessContributions(obj)
        % NestednessContributions - Perform the nestedness contribution Statistical Analysis
        %   obj = NestednessContributions(obj) Perform the nestedness contribution Statistical analsysis. Be
        %   sure to create the random matrices before calling this
        %   function. Otherwise only 100 equiprobable random matrices will
        %   be used for the analysis
        
            if(isempty(obj.nulls))
                obj.DoNulls();
            end
            [obj.nest_row_contrib obj.nest_col_contrib] = Test.GET_NEST_CONTRIBUTIONS(obj.bipweb.adjacency,obj.nulls);
            obj.nest_contrib_done = 1;
        end
        
    end
    
    methods(Static)
        
        function [out_b out_r] = GET_DEV_MODUL(webbip,rmatrices)
        % GET_DEV_MODUL - Perform a Modularity Statistical Analysis
        %   [out_b out_r] =  GET_DEV_MODUL(webbip,rmatrices) Perform t-test and
        %   z-test in the modularity value of the bipartite object webbip using
        %   the ser of random matrices rmatrices. Return an
        %   structure for both Qb (standard modularity definition) and Qr
        %   (ratio of inside module vs total interactions). These
        %   structures contain the next values:
        %      value   - The value in the empirical matrix
        %      p       - p-value of the performed t-test
        %      ci      - Confidence interval of the performet t-test
        %      percent - The percent of random networks for which  the
        %                empirical value is bigger than the value of the random
        %                networks
        %      z       - z-score of the empirical value
        
            wQr = webbip.modules.Qr;
            wQb = webbip.modules.Qb;
            n = length(rmatrices);
            
            Qb_random = zeros(n,1);
            Qr_random = zeros(n,1);
            
            modul_class = str2func(class(webbip.modules));
            n_trials = webbip.modules.trials;
            for i = 1:n
                modularity = modul_class(rmatrices{i});
                modularity.trials = n_trials;
                modularity.Detect(10);
                Qb_random(i) = modularity.Qb;
                Qr_random(i) = modularity.Qr; 
                %fprintf('Trial %i:\n', i);
            end
            
            [hb pb cib] = ttest(Qb_random, wQb);
            [hr pr cir] = ttest(Qr_random, wQr);
            
            cib = [sum(cib)/2; cib];
            cir = [sum(cir)/2; cir];
            
            z_qb = (webbip.modules.Qb - mean(Qb_random))/std(Qb_random);
            z_qr = (webbip.modules.Qr - mean(Qr_random))/std(Qr_random);
            
            percent_qb = sum(webbip.modules.Qb>Qb_random)/n;
            percent_qr = sum(webbip.modules.Qr>Qr_random)/n;
            
            
            out_b.value = wQb; out_b.p = pb; out_b.ci = cib; out_b.zscore = z_qb; out_b.percent = percent_qb;
            out_r.value = wQr; out_r.p = pr; out_r.ci = cir; out_r.zscore = z_qr; out_r.percent = percent_qr;
            
        end
        
        function [out out_row out_col] = GET_DEV_NEST(webbip,rmatrices) 
        % GET_DEV_NEST - Perform a NODF Statistical Analysis
        %   [out out_row out_col] =  GET_DEV_NEST(webbip,rmatrices) Perform t-test and
        %   z-test in the NODF value of the bipartite object webbip using
        %   the ser of random matrices rmatrices. Return a
        %   structure for nodf values in the entire matrix(out), rows (out_row)
        %   and columns (out_col) with the next elements:
        %      value   - The value in the empirical matrix
        %      p       - p-value of the performed t-test
        %      ci      - Confidence interval of the performet t-test
        %      percent - The percent of random networks for which  the
        %                empirical value is bigger than the value of the random
        %                networks
        %      z       - z-score of the empirical value    
            n = length(rmatrices);
            expect = zeros(n,1);
            expect_row = zeros(n,1);
            expect_col = zeros(n,1);
            
            for i = 1:n
                Nodf = NODF(rmatrices{i});
                expect(i) = Nodf.nodf;
                expect_row(i) = Nodf.nodf_rows;
                expect_col(i) = Nodf.nodf_cols;
            end
            
            [h p ci] = ttest(expect, webbip.nodf.nodf);
            [h p_row ci_row] = ttest(expect_row, webbip.nodf.nodf_rows);
            [h p_col ci_col] = ttest(expect_col, webbip.nodf.nodf_cols);
            
            
            ci = [sum(ci)/2; ci];
            ci_row = [sum(ci_row)/2; ci_row];
            ci_col = [sum(ci_col)/2; ci_col];
            z_nest = (webbip.nodf.nodf - mean(expect))/std(expect);
            z_nest_row = (webbip.nodf.nodf_rows - mean(expect_row))/std(expect_row);
            z_nest_col = (webbip.nodf.nodf_cols - mean(expect_col))/std(expect_col);
            percent = sum(webbip.nodf.nodf>expect)/n;
            percent_row = sum(webbip.nodf.nodf>expect_row)/n;
            percent_col = sum(webbip.nodf.nodf>expect_col)/n;
            
            out.value = webbip.nodf.nodf; out.p = p; out.ci = ci; out.zscore = z_nest; out.percent = percent;
            out_row.value = webbip.nodf.nodf_rows; out_row.p = p_row; out_row.ci = ci_row; out_row.zscore = z_nest_row; out_row.percent = percent_row;
            out_col.value = webbip.nodf.nodf_cols; out_col.p = p_col; out_col.ci = ci_col; out_col.zscore = z_nest_col; out_col.percent = percent_col;
            
        end
        
        function [out] = GET_DEV_TEMP(webbip,rmatrices)
        % GET_DEV_TEMP - Perform a NTC Statistical Analysis
        %   [out out_row out_col] =  GET_DEV_TEMP(webbip,rmatrices) Perform t-test and
        %   z-test in the NTC value of the bipartite object webbip using
        %   the ser of random matrices rmatrices. Return a
        %   structure for NTC statistical values in the entire matrix(out)
        %   with the next elements:
        %      value   - The value in the empirical matrix
        %      p       - p-value of the performed t-test
        %      ci      - Confidence interval of the performet t-test
        %      percent - The percent of random networks for which  the
        %                empirical value is bigger than the value of the random
        %                networks
        %      z       - z-score of the empirical value                 
            n = length(rmatrices);
            nestedness = NestednessBINMATNEST(webbip.webmatrix>0);
            nestedness.CalculateNestedness();
            ntc = nestedness.N;
            
            expect = zeros(n,1);
            
            for i = 1:n
                nestedness.SetMatrix(rmatrices{i});
                nestedness.DoGeometry = 0;
                nestedness.CalculateNestedness();
                expect(i) = nestedness.N;
                %fprintf('Trial %i:\n', i);
            end
            
            [h p ci] = ttest(expect, webbip.ntc.N);
            
            ci = [sum(ci)/2; ci];
            z_nest = (ntc - mean(expect))/std(expect);
            percent = sum(ntc>expect)/n;
            
            out.ntc = ntc; out.p = p; out.ci = ci; out.zscore = z_nest; out.percent = percent;
            
        end
        
        function [out] = GET_DEV_EIG(webbip,rmatrices)
        % GET_DEV_EIG - Perform a spectral radius Statistical Analysis
        %   [out out_row out_col] =  GET_DEV_EIG(webbip,rmatrices) Perform t-test and
        %   z-test in the NTC value of the bipartite object webbip using
        %   the ser of random matrices rmatrices. Return a
        %   structure for NTC statistical values in the entire matrix(out)
        %   with the next elements:
        %      value   - The value in the empirical matrix
        %      p       - p-value of the performed t-test
        %      ci      - Confidence interval of the performet t-test
        %      percent - The percent of random networks for which  the
        %                empirical value is bigger than the value of the random
        %                networks
        %      z       - z-score of the empirical value      
            n = length(rmatrices);
            expect = zeros(n,1);
            
            out.maxe = MatrixNull.GetBiggestEigenvalue(webbip.adjacency);
            
            for i = 1:n
                expect(i) = MatrixNull.GetBiggestEigenvalue(rmatrices{i});
            end
            
            [h p ci] = ttest(expect, out.maxe);
            
            ci = [sum(ci)/2; ci];
            z_nest = (out.maxe - mean(expect))/std(expect);
            percent = sum(out.maxe>expect)/n;
            
            out.p = p; out.ci = ci; out.zscore = z_nest; out.percent = percent;
            
        end
        
        function [c_rows c_cols] = GET_NEST_CONTRIBUTIONS(matrix, rmatrices)
        % GET_NEST_CONTRIBUTIONS - Get NODF nestedness contributions of a
        % matrix
        %   [c_rows c_cols] = GET_NEST_CONTRIBUTIONS(matrix, rmatrices) Get
        %   the NODF contributions for both rows and columns. The
        %   contribution is calculated as the z-score of each individually
        %   randomly permuted row and columns
            nodf = NODF(matrix);
            N = nodf.nodf;
            [n_rows n_cols] = size(matrix);
            nn = length(rmatrices);
            row_contrib = zeros(nn,n_rows);
            col_contrib = zeros(nn,n_cols);
            orig_matrix = matrix;
            for i = 1:n_rows
                temp_row = matrix(i,:);
                for j = 1:nn
                    matrix(i,:) = rmatrices{j}(i,:);
                    nodf = NODF(matrix,0);
                    row_contrib(j,i) = nodf.nodf;
                    if(isnan(nodf.nodf))
                        continue;
                    end
                end
                matrix(i,:) = temp_row;
            end
            
            for i = 1:n_cols
                temp_col = matrix(:,i);
                for j = 1:nn
                    matrix(:,i) = rmatrices{j}(:,i);
                    nodf = NODF(matrix,0);
                    col_contrib(j,i) = nodf.nodf;
                end
                matrix(:,i) = temp_col;
            end
            std_rows = std(row_contrib);
            std_cols = std(col_contrib);
            mean_rows = mean(row_contrib);
            mean_cols = mean(col_contrib);
            
            c_rows = (N - mean_rows)./std_rows;
            c_cols = (N - mean_cols)./std_cols;
            
        end
        
    end

end
