classdef GroupTesting < handle
   
    properties
        matrices = {};
        adaptive_modular;
        nodf_nested;
        ntc_nested;
        eig_nested;
        z_nested;
        n_matrices = 0;
    end
    
    methods
        
        function obj = GroupTesting(matrices)
            
            obj.n_matrices = length(matrices);
            obj.matrices = matrices;
            
            for i = 1:obj.n_matrices
                obj.matrices{i} = MatrixNull.NON_ZERO_MATRIX(obj.matrices{i}>0);
            end
        end
        
        function obj = DoTotalGroupTesting(obj,n_trials)
            
            n = obj.n_matrices;
            
            for i = 1:n
                bn = Bipartite(obj.matrices{i});
                bn.tests.print_output = 0;
                bn.tests.DoCompleteAnalysis(n_trials);
                obj.adaptive_modular.v(i) = bn.tests.qb_vals.Qb;
                obj.adaptive_modular.z(i) = bn.tests.qb_vals.zscore;
                obj.adaptive_modular.p(i) = bn.tests.qb_vals.percent;
                
                obj.nodf_nested.v(i) = bn.tests.nestvals.nodf;
                obj.nodf_nested.z(i) = bn.tests.nestvals.zscore;
                obj.nodf_nested.p(i) = bn.tests.nestvals.percent;
                
                obj.ntc_nested.v(i) = bn.tests.tempvals.ntc;
                obj.ntc_nested.z(i) = bn.tests.tempvals.zscore;
                obj.ntc_nested.p(i) = bn.tests.tempvals.percent;
                
                obj.eig_nested.v(i) = bn.tests.eigvals.maxe;
                obj.eig_nested.z(i) = bn.tests.eigvals.zscore;
                obj.eig_nested.p(i) = bn.tests.eigvals.percent;
                fprintf('Testing Matrix: %i\n', i);
            end
            
        end
        
    end
    
    methods(Static)
       
        function [matrices names] = GET_MATRICES_FROM_FILES(file_name)
            
            [pathstr, name, ext] = fileparts(file_name);
            files = dir(file_name);
            
            for i = 1:length(files)
               
                fprintf('%s\n',files(i).name);
                matrices{i} = dlmread([pathstr,'/',files(i).name]);
                
                [~, name, ~] = fileparts(files(i).name);
                names{i} = name;
                
            end
            
        end
        
    end
    
    
end