classdef TestModules < handle
   
    properties(GetAccess = 'public', SetAccess = 'public')
        bipweb          = [];
        randomindex     = [];
        realindex       = [];
        rows_idx        = [];
        cols_idx        = [];
        module_networks = [];
    end
    
    methods
        function obj = TestModules(webbip)
            
            obj.bipweb = webbip;

        end

        function TestDiversityRows(obj,n_trials,rows_ids,index_function)
            RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
            assert(length(rows_ids)==obj.bipweb.modules.n_rows);
            
            if(nargin == 1)
                n_trials = 100;
                rows_ids = obj.rows_idx;
                index_function = @Diversity.SIMPSON_INDEX;
            elseif(nargin==2)
                rows_ids = obj.rows_idx;
                index_function = @Diversity.SIMPSON_INDEX;
            end
            
            modul = obj.bipweb.modules;
            
            randomdata = zeros(n_trials, modul.N);
            prandom = zeros(1,modul.N);
            obj.realindex.rows = zeros(modul.N,1);
            obj.rows_idx = rows_ids;
            
            [row_modules, ~] = modul.ExtractCommunityIndexes();
            
            n = length(rows_ids);
            for i = 1:modul.N
                
                obj.realindex.rows(i) = index_function(rows_ids(row_modules{i}));
                nr = length(row_modules{i});
                for j = 1:n_trials
                    rows_idx_random = rows_ids(randperm(n));
                    randomdata(j,i) = index_function(rows_idx_random(1:nr));
                end
                randomdata(:,i) = sort(randomdata(:,i));
                prandom(i) = sum(obj.realindex.rows(i)>randomdata(:,i))/n_trials;
            end
            obj.randomindex.rows.zscore = (obj.realindex.rows' - mean(randomdata))./std(randomdata);
            obj.randomindex.rows.data = randomdata;
            obj.randomindex.rows.p_values = prandom;
            
            fprintf('Diversity in Rows unsing %s\n',func2str(index_function));
            fprintf('Module \t index \t zscore \t percent \n');
            for i = 1:modul.N
                fprintf('%i \t %f \t %f \t %f \n', i, obj.realindex.rows(i), obj.randomindex.rows.zscore(i), obj.randomindex.rows.p_values(i));
            end
        end
        
        function TestInternalModules(obj,n_trials,null_model)
            
            if(nargin == 1)
                n_trials = 100;
                null_model = @NullModels.NULL_1;
            elseif(nargin == 2)
                null_model = @NullModels.NULL_1;
            end
            
            obj.module_networks = obj.ExtractCommunityModules();
            
            for net = obj.module_networks
                %display(net{1}.adjacency);
                if(isempty(net{1}.webmatrix))
                    continue;
                end
                net{1}.tests.DoCompleteAnalysis(n_trials,null_model);
                
            end
            
            i = 1;
            fprintf('Module \t Modularity \t zscore \t percent \t NODF \t zscore \t percent \t NTC \t zscore \t percet \n');
            for net = obj.module_networks
                if(isempty(net{1}.webmatrix))
                    continue;
                end
                fprintf('%i \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \n', ...
                i, ...
                net{1}.tests.qb_vals.Qb, net{1}.tests.qb_vals.zscore, net{1}.tests.qb_vals.percent, ...
                net{1}.tests.nestvals.nodf, net{1}.tests.nestvals.zscore, net{1}.tests.nestvals.percent, ...
                net{1}.tests.tempvals.ntc, net{1}.tests.tempvals.zscore, net{1}.tests.tempvals.percent);
            
                i = i+1;
            end
            
        end
        
        function row_nets = TestRowsByLabeling(obj,rows_idx,n_trials,null_model)
            
            if(nargin == 1)
                n_trials = 100;
                null_model = @NullModels.NULL_1;
                rows_idx = obj.bipweb.rows_idx;
            elseif(nargin == 2)
                n_trials = 100;
                null_model = @NullModels.NULL_1;
            elseif(nargin == 3)
                null_model = @NullModels.NULL_1;
            end
            
            row_nets = obj.GetNetsByRowLabeling(rows_idx);
            
            TestModules.TestNetworks(row_nets,n_trials,null_model)
            
        end
        
        function inter_nets = TestByInteractions(obj,n_trials,null_model)
            
            if(nargin == 1)
                n_trials = 100;
                null_model = @NullModels.NULL_1;
            elseif(nargin == 2)
                n_trials = 100;
            end
            
            inter_nets = obj.GetNetsByInteractions();
            
            TestModules.TestNetworks(inter_nets,n_trials,null_model)
            
        end
        
        function [nets row_idx] = GetNetsByRowLabeling(obj,row_labels)
            
            if(nargin==1)
                row_labels = obj.bipweb.rows_idx;
            end
            idx = unique(row_labels);
            n_nets = length(idx);
            nets = cell(n_nets,1);
            row_idx = cell(n_nets,1);
            matrix = obj.bipweb.webmatrix;
            
            for i = 1:n_nets
                idx_rows = find(row_labels==idx(i));
                nets{i} = Bipartite(matrix(idx_rows,:));
                nets{i}.rows_idx = obj.bipweb.rows_idx(idx_rows);
                nets{i}.row_labels = obj.bipweb.row_labels(idx_rows);
                nets{i}.col_labels = obj.bipweb.col_labels;
                row_idx{i} = idx_rows;
            end
            
        end
        
        function [nets row_idx col_idx]= GetNetsByInteractions(obj)
            
            matrix = obj.bipweb.webmatrix;
            idx = unique(matrix);
            if(idx(1) == 0); idx(1) = []; end;
            n_nets = length(idx);
            nets = cell(n_nets,1);
            row_idx = cell(n_nets,1);
            
            for i = 1:n_nets
                [matrix_ex idx_rows idx_cols] = MatrixNull.TYPE_MATRIX_NON_ZERO(matrix, idx(i));
                nets{i} = Bipartite(matrix_ex);
                nets{i}.rows_idx = obj.bipweb.rows_idx(idx_rows);                
                nets{i}.row_labels = obj.bipweb.row_labels(idx_rows);
                %nets{i}.cols_idx = obj.bipweb.cols_idx(idx_cols);
                nets{i}.col_labels = obj.bipweb.col_labels(idx_cols);
                row_idx{i} = idx_rows;
                col_idx{i} = idx_cols;
            end
            
        end
        
        function networks = ExtractCommunityModules(obj)
            modul = obj.bipweb.modules;
            for i = 1:modul.N
                idx_rows = find(modul.rr(:,i)==1);
                idx_cols = find(modul.tt(:,i)==1);
                ma = modul.webmatrix(idx_rows,idx_cols);
                networks{i} = Bipartite(ma);
                networks{i}.row_labels = obj.bipweb.row_labels(idx_rows);
                networks{i}.col_labels = obj.bipweb.col_labels(idx_cols);
                if(~isempty(obj.bipweb.rows_idx))
                    networks{i}.rows_idx = obj.bipweb.rows_idx(idx_rows);
                end
            end 
        end
        
        function CreateModuleTableProperties(obj)
            
            modules = obj.module_networks;
            nn = length(modules);
            
            fprintf('No. \t H \t P \t S \t I \t M \t C \t Lh \t Lp\n');
            
            for i = 1:nn
                H = modules{i}.n_rows;
                P = modules{i}.n_cols;
                S = H+P;
                I = sum(sum(modules{i}.adjacency));
                M = H*P;
                C = I/M;
                Lh = I/H;
                Lp = I/P;
                fprintf('%i \t %i \t %i \t %i \t %i \t %i \t %f \t %f \t %f\n', ...
                    i, H, P, S, I, M, C, Lh, Lp);
            end
            
        end
        
        function TestNODFModuleContributions(obj)
            matrix = obj.bipweb.adjacency;
            rr = obj.bipweb.modules.rr;
            tt = obj.bipweb.modules.tt;
            
            [n_rows n_cols] = size(matrix);
            
            rows_sum = sum(matrix,2);
            col_sum = sum(matrix,1);
            
            [row,col] = find(rr);[a,ix] = sort(row);row_modules = col(ix);
            [row,col] = find(tt);[a,ix] = sort(row);col_modules = col(ix);
            
            nij_row_in = 0;
            nij_row_out = 0;
            for i = 1:n_rows
                for j = i+1:n_rows
                    cont = sum(matrix(i,:).*matrix(j,:))*(rows_sum(i)~=rows_sum(j))/min(sum(matrix(i,:)),sum(matrix(j,:)));
                    if(~isnan(cont))
                        if(row_modules(i) == row_modules(j))
                            nij_row_in = nij_row_in + cont;
                        else
                            nij_row_out = nij_row_out + cont;
                        end
                    end
                end
            end
            
            nij_col_in = 0;
            nij_col_out = 0;
            for i = 1:n_cols
                for j = i+1:n_cols
                    cont = sum(matrix(:,i).*matrix(:,j))*(col_sum(i)~=col_sum(j))/min(sum(matrix(:,i)),sum(matrix(:,j)));
                    if(col_modules(i) == col_modules(j))
                        nij_col_in = nij_col_in + cont;
                    else
                        nij_col_out = nij_col_out + cont;
                    end
                end
            end
            
            denom = n_rows*(n_rows-1)/2 + n_cols*(n_cols-1)/2;
            nodf_in = 100.0*(nij_row_in+nij_col_in)/denom;
            nodf_out = 100.0*(nij_row_out+nij_col_out)/denom;
            nodf = nodf_in + nodf_out;
                
        end
        
    end
    
    methods(Static)
       
        function TestNetworks(networks,n_trials,null_model)
            
            if(nargin == 2)
                n_trials = 100;
                null_model = @NullModels.NULL_1;
            elseif(nargin == 3)
                null_model = @NullModels.NULL_1;
            end
                        
            
            for i = 1:length(networks)
                %display(net{1}.adjacency);
                if(isempty(networks{i}.webmatrix))
                    continue;
                end
                networks{i}.tests.DoCompleteAnalysis(null_model,n_trials);
                
            end
            
            fprintf('Network \t Modularity \t zscore \t percent \t NODF \t zscore \t percent \t NTC \t zscore \t percet \n');
            for i = 1:length(networks)
                if(isempty(networks{i}.webmatrix))
                    continue;
                end
                fprintf('%i \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \t %f \n', ...
                i, ...
                networks{i}.tests.qb_vals.Qb, networks{i}.tests.qb_vals.zscore, networks{i}.tests.qb_vals.percent, ...
                networks{i}.tests.nestvals.nodf, networks{i}.tests.nestvals.zscore, networks{i}.tests.nestvals.percent, ...
                networks{i}.tests.tempvals.ntc, networks{i}.tests.tempvals.zscore, networks{i}.tests.tempvals.percent);
            end
            
        end
        
    end
    
end